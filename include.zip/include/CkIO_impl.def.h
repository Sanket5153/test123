
namespace Ck {
namespace IO {
namespace impl {

/* ---------------- method closures -------------- */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Director::openFile_2_closure : public SDAG::Closure {
            std::string name;
            CkCallback opened;
            Options opts;


      openFile_2_closure() {
        init();
      }
      openFile_2_closure(CkMigrateMessage*) {
        init();
      }
            std::string & getP0() { return name;}
            CkCallback & getP1() { return opened;}
            Options & getP2() { return opts;}
      void pup(PUP::er& __p) {
        __p | name;
        __p | opened;
        __p | opts;
        packClosure(__p);
      }
      virtual ~openFile_2_closure() {
      }
      PUPable_decl(SINGLE_ARG(openFile_2_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Director::fileOpened_3_closure : public SDAG::Closure {
            FileToken file;


      fileOpened_3_closure() {
        init();
      }
      fileOpened_3_closure(CkMigrateMessage*) {
        init();
      }
            FileToken & getP0() { return file;}
      void pup(PUP::er& __p) {
        __p | file;
        packClosure(__p);
      }
      virtual ~fileOpened_3_closure() {
      }
      PUPable_decl(SINGLE_ARG(fileOpened_3_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Director::sessionComplete_4_closure : public SDAG::Closure {
            FileToken file;


      sessionComplete_4_closure() {
        init();
      }
      sessionComplete_4_closure(CkMigrateMessage*) {
        init();
      }
            FileToken & getP0() { return file;}
      void pup(PUP::er& __p) {
        __p | file;
        packClosure(__p);
      }
      virtual ~sessionComplete_4_closure() {
      }
      PUPable_decl(SINGLE_ARG(sessionComplete_4_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Director::closeReadSession_5_closure : public SDAG::Closure {
            Session impl_noname_0;
            CkCallback impl_noname_1;


      closeReadSession_5_closure() {
        init();
      }
      closeReadSession_5_closure(CkMigrateMessage*) {
        init();
      }
            Session & getP0() { return impl_noname_0;}
            CkCallback & getP1() { return impl_noname_1;}
      void pup(PUP::er& __p) {
        __p | impl_noname_0;
        __p | impl_noname_1;
        packClosure(__p);
      }
      virtual ~closeReadSession_5_closure() {
      }
      PUPable_decl(SINGLE_ARG(closeReadSession_5_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Director::prepareReadSession_6_closure : public SDAG::Closure {
            FileToken file;
            size_t bytes;
            size_t offset;
            CkCallback ready;


      prepareReadSession_6_closure() {
        init();
      }
      prepareReadSession_6_closure(CkMigrateMessage*) {
        init();
      }
            FileToken & getP0() { return file;}
            size_t & getP1() { return bytes;}
            size_t & getP2() { return offset;}
            CkCallback & getP3() { return ready;}
      void pup(PUP::er& __p) {
        __p | file;
        __p | bytes;
        __p | offset;
        __p | ready;
        packClosure(__p);
      }
      virtual ~prepareReadSession_6_closure() {
      }
      PUPable_decl(SINGLE_ARG(prepareReadSession_6_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Director::prepareReadSession_7_closure : public SDAG::Closure {
            FileToken file;
            size_t bytes;
            size_t offset;
            CkCallback ready;
            std::vector<int> pes_to_map;


      prepareReadSession_7_closure() {
        init();
      }
      prepareReadSession_7_closure(CkMigrateMessage*) {
        init();
      }
            FileToken & getP0() { return file;}
            size_t & getP1() { return bytes;}
            size_t & getP2() { return offset;}
            CkCallback & getP3() { return ready;}
            std::vector<int> & getP4() { return pes_to_map;}
      void pup(PUP::er& __p) {
        __p | file;
        __p | bytes;
        __p | offset;
        __p | ready;
        __p | pes_to_map;
        packClosure(__p);
      }
      virtual ~prepareReadSession_7_closure() {
      }
      PUPable_decl(SINGLE_ARG(prepareReadSession_7_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Director::prepareWriteSession_8_closure : public SDAG::Closure {
            FileToken file;
            size_t bytes;
            size_t offset;
            CkCallback ready;
            CkCallback complete;


      prepareWriteSession_8_closure() {
        init();
      }
      prepareWriteSession_8_closure(CkMigrateMessage*) {
        init();
      }
            FileToken & getP0() { return file;}
            size_t & getP1() { return bytes;}
            size_t & getP2() { return offset;}
            CkCallback & getP3() { return ready;}
            CkCallback & getP4() { return complete;}
      void pup(PUP::er& __p) {
        __p | file;
        __p | bytes;
        __p | offset;
        __p | ready;
        __p | complete;
        packClosure(__p);
      }
      virtual ~prepareWriteSession_8_closure() {
      }
      PUPable_decl(SINGLE_ARG(prepareWriteSession_8_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Director::prepareWriteSession_9_closure : public SDAG::Closure {
            FileToken file;
            size_t bytes;
            size_t offset;
            CkCallback ready;
            char *commitData;
            size_t commitBytes;
            size_t commitOffset;
            CkCallback complete;

      CkMarshallMsg* _impl_marshall;
      char* _impl_buf_in;
      int _impl_buf_size;

      prepareWriteSession_9_closure() {
        init();
        _impl_marshall = 0;
        _impl_buf_in = 0;
        _impl_buf_size = 0;
      }
      prepareWriteSession_9_closure(CkMigrateMessage*) {
        init();
        _impl_marshall = 0;
        _impl_buf_in = 0;
        _impl_buf_size = 0;
      }
            FileToken & getP0() { return file;}
            size_t & getP1() { return bytes;}
            size_t & getP2() { return offset;}
            CkCallback & getP3() { return ready;}
            char *& getP4() { return commitData;}
            size_t & getP5() { return commitBytes;}
            size_t & getP6() { return commitOffset;}
            CkCallback & getP7() { return complete;}
      void pup(PUP::er& __p) {
        __p | file;
        __p | bytes;
        __p | offset;
        __p | ready;
        __p | commitBytes;
        __p | commitOffset;
        __p | complete;
        packClosure(__p);
        __p | _impl_buf_size;
        bool hasMsg = (_impl_marshall != 0); __p | hasMsg;
        if (hasMsg) CkPupMessage(__p, (void**)&_impl_marshall);
        else PUParray(__p, _impl_buf_in, _impl_buf_size);
        if (__p.isUnpacking()) {
          char *impl_buf = _impl_marshall ? _impl_marshall->msgBuf : _impl_buf_in;
          PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<CkCallback> ready;
  implP|ready;
  int impl_off_commitData, impl_cnt_commitData;
  implP|impl_off_commitData;
  implP|impl_cnt_commitData;
  PUP::detail::TemporaryObjectHolder<size_t> commitBytes;
  implP|commitBytes;
  PUP::detail::TemporaryObjectHolder<size_t> commitOffset;
  implP|commitOffset;
  PUP::detail::TemporaryObjectHolder<CkCallback> complete;
  implP|complete;
          impl_buf+=CK_ALIGN(implP.size(),16);
          commitData = (char *)(impl_buf+impl_off_commitData);
        }
      }
      virtual ~prepareWriteSession_9_closure() {
        if (_impl_marshall) CmiFree(UsrToEnv(_impl_marshall));
      }
      PUPable_decl(SINGLE_ARG(prepareWriteSession_9_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Director::close_12_closure : public SDAG::Closure {
            FileToken token;
            CkCallback closed;


      close_12_closure() {
        init();
      }
      close_12_closure(CkMigrateMessage*) {
        init();
      }
            FileToken & getP0() { return token;}
            CkCallback & getP1() { return closed;}
      void pup(PUP::er& __p) {
        __p | token;
        __p | closed;
        packClosure(__p);
      }
      virtual ~close_12_closure() {
      }
      PUPable_decl(SINGLE_ARG(close_12_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */


/* ---------------- method closures -------------- */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_ReadAssembler::shareData_2_closure : public SDAG::Closure {
            int read_tag;
            int buffer_tag;
            size_t read_chare_offset;
            size_t num_bytes;
            int num_rdma_fields;
      int num_root_node;
      CkNcpyBuffer ncpyBuffer_data;

      CkMarshallMsg* _impl_marshall;
      char* _impl_buf_in;
      int _impl_buf_size;

      shareData_2_closure() {
        init();
        _impl_marshall = 0;
        _impl_buf_in = 0;
        _impl_buf_size = 0;
      }
      shareData_2_closure(CkMigrateMessage*) {
        init();
        _impl_marshall = 0;
        _impl_buf_in = 0;
        _impl_buf_size = 0;
      }
            int & getP0() { return read_tag;}
            int & getP1() { return buffer_tag;}
            size_t & getP2() { return read_chare_offset;}
            size_t & getP3() { return num_bytes;}
            int & getP4() { return  num_rdma_fields;}
      int & getP5() { return  num_root_node;}
      CkNcpyBuffer & getP6() { return ncpyBuffer_data;}
      void pup(PUP::er& __p) {
        __p | read_tag;
        __p | buffer_tag;
        __p | read_chare_offset;
        __p | num_bytes;
        char *impl_buf = _impl_marshall ? _impl_marshall->msgBuf : _impl_buf_in;
        __p | num_rdma_fields;
        __p | num_root_node;
        if (__p.isPacking()) {
          ncpyBuffer_data.ptr = (void *)((char *)(ncpyBuffer_data.ptr) - impl_buf);
        }
        __p | ncpyBuffer_data;
        packClosure(__p);
        __p | _impl_buf_size;
        bool hasMsg = (_impl_marshall != 0); __p | hasMsg;
        if (hasMsg) CkPupMessage(__p, (void**)&_impl_marshall);
        else PUParray(__p, _impl_buf_in, _impl_buf_size);
        if (__p.isUnpacking()) {
          char *impl_buf = _impl_marshall ? _impl_marshall->msgBuf : _impl_buf_in;
          PUP::fromMem implP(impl_buf);
  ncpyBuffer_data.ptr = (void *)(impl_buf + (size_t)(ncpyBuffer_data.ptr));
  implP|num_rdma_fields;
  implP|num_root_node;
  CkNcpyBuffer ncpyBuffer_data;
  implP|ncpyBuffer_data;
  char *ncpyBuffer_data_ptr = nullptr;
  PUP::detail::TemporaryObjectHolder<int> read_tag;
  implP|read_tag;
  PUP::detail::TemporaryObjectHolder<int> buffer_tag;
  implP|buffer_tag;
  PUP::detail::TemporaryObjectHolder<size_t> read_chare_offset;
  implP|read_chare_offset;
  PUP::detail::TemporaryObjectHolder<size_t> num_bytes;
  implP|num_bytes;
          impl_buf+=CK_ALIGN(implP.size(),16);
        }
      }
      virtual ~shareData_2_closure() {
        if (_impl_marshall) CmiFree(UsrToEnv(_impl_marshall));
      }
      PUPable_decl(SINGLE_ARG(shareData_2_closure));
    };
#endif /* CK_TEMPLATES_ONLY */


/* ---------------- method closures -------------- */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Manager::run_2_closure : public SDAG::Closure {
      

      run_2_closure() {
        init();
      }
      run_2_closure(CkMigrateMessage*) {
        init();
      }
            void pup(PUP::er& __p) {
        packClosure(__p);
      }
      virtual ~run_2_closure() {
      }
      PUPable_decl(SINGLE_ARG(run_2_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Manager::openFile_3_closure : public SDAG::Closure {
            unsigned int opnum;
            FileToken token;
            std::string name;
            Options opts;


      openFile_3_closure() {
        init();
      }
      openFile_3_closure(CkMigrateMessage*) {
        init();
      }
            unsigned int & getP0() { return opnum;}
            FileToken & getP1() { return token;}
            std::string & getP2() { return name;}
            Options & getP3() { return opts;}
      void pup(PUP::er& __p) {
        __p | opnum;
        __p | token;
        __p | name;
        __p | opts;
        packClosure(__p);
      }
      virtual ~openFile_3_closure() {
      }
      PUPable_decl(SINGLE_ARG(openFile_3_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Manager::close_4_closure : public SDAG::Closure {
            unsigned int opnum;
            FileToken token;
            CkCallback closed;


      close_4_closure() {
        init();
      }
      close_4_closure(CkMigrateMessage*) {
        init();
      }
            unsigned int & getP0() { return opnum;}
            FileToken & getP1() { return token;}
            CkCallback & getP2() { return closed;}
      void pup(PUP::er& __p) {
        __p | opnum;
        __p | token;
        __p | closed;
        packClosure(__p);
      }
      virtual ~close_4_closure() {
      }
      PUPable_decl(SINGLE_ARG(close_4_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_Manager::addSessionReadAssemblerMapping_5_closure : public SDAG::Closure {
            Session session;
            CProxy_ReadAssembler ra;
            CkCallback ready;


      addSessionReadAssemblerMapping_5_closure() {
        init();
      }
      addSessionReadAssemblerMapping_5_closure(CkMigrateMessage*) {
        init();
      }
            Session & getP0() { return session;}
            CProxy_ReadAssembler & getP1() { return ra;}
            CkCallback & getP2() { return ready;}
      void pup(PUP::er& __p) {
        __p | session;
        __p | ra;
        __p | ready;
        packClosure(__p);
      }
      virtual ~addSessionReadAssemblerMapping_5_closure() {
      }
      PUPable_decl(SINGLE_ARG(addSessionReadAssemblerMapping_5_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */


/* ---------------- method closures -------------- */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_WriteSession::forwardData_2_closure : public SDAG::Closure {
            char *data;
            size_t bytes;
            size_t offset;

      CkMarshallMsg* _impl_marshall;
      char* _impl_buf_in;
      int _impl_buf_size;

      forwardData_2_closure() {
        init();
        _impl_marshall = 0;
        _impl_buf_in = 0;
        _impl_buf_size = 0;
      }
      forwardData_2_closure(CkMigrateMessage*) {
        init();
        _impl_marshall = 0;
        _impl_buf_in = 0;
        _impl_buf_size = 0;
      }
            char *& getP0() { return data;}
            size_t & getP1() { return bytes;}
            size_t & getP2() { return offset;}
      void pup(PUP::er& __p) {
        __p | bytes;
        __p | offset;
        packClosure(__p);
        __p | _impl_buf_size;
        bool hasMsg = (_impl_marshall != 0); __p | hasMsg;
        if (hasMsg) CkPupMessage(__p, (void**)&_impl_marshall);
        else PUParray(__p, _impl_buf_in, _impl_buf_size);
        if (__p.isUnpacking()) {
          char *impl_buf = _impl_marshall ? _impl_marshall->msgBuf : _impl_buf_in;
          PUP::fromMem implP(impl_buf);
  int impl_off_data, impl_cnt_data;
  implP|impl_off_data;
  implP|impl_cnt_data;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
          impl_buf+=CK_ALIGN(implP.size(),16);
          data = (char *)(impl_buf+impl_off_data);
        }
      }
      virtual ~forwardData_2_closure() {
        if (_impl_marshall) CmiFree(UsrToEnv(_impl_marshall));
      }
      PUPable_decl(SINGLE_ARG(forwardData_2_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_WriteSession::syncData_3_closure : public SDAG::Closure {
      

      syncData_3_closure() {
        init();
      }
      syncData_3_closure(CkMigrateMessage*) {
        init();
      }
            void pup(PUP::er& __p) {
        packClosure(__p);
      }
      virtual ~syncData_3_closure() {
      }
      PUPable_decl(SINGLE_ARG(syncData_3_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */


/* ---------------- method closures -------------- */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_BufferChares::sendData_2_closure : public SDAG::Closure {
            int read_tag;
            int buffer_tag;
            size_t offset;
            size_t bytes;
            CProxy_ReadAssembler ra;
            int pe;


      sendData_2_closure() {
        init();
      }
      sendData_2_closure(CkMigrateMessage*) {
        init();
      }
            int & getP0() { return read_tag;}
            int & getP1() { return buffer_tag;}
            size_t & getP2() { return offset;}
            size_t & getP3() { return bytes;}
            CProxy_ReadAssembler & getP4() { return ra;}
            int & getP5() { return pe;}
      void pup(PUP::er& __p) {
        __p | read_tag;
        __p | buffer_tag;
        __p | offset;
        __p | bytes;
        __p | ra;
        __p | pe;
        packClosure(__p);
      }
      virtual ~sendData_2_closure() {
      }
      PUPable_decl(SINGLE_ARG(sendData_2_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_BufferChares::sendDataHandler_3_closure : public SDAG::Closure {
            int read_tag;
            int buffer_tag;
            size_t offset;
            size_t bytes;
            CProxy_ReadAssembler ra;
            int pe;


      sendDataHandler_3_closure() {
        init();
      }
      sendDataHandler_3_closure(CkMigrateMessage*) {
        init();
      }
            int & getP0() { return read_tag;}
            int & getP1() { return buffer_tag;}
            size_t & getP2() { return offset;}
            size_t & getP3() { return bytes;}
            CProxy_ReadAssembler & getP4() { return ra;}
            int & getP5() { return pe;}
      void pup(PUP::er& __p) {
        __p | read_tag;
        __p | buffer_tag;
        __p | offset;
        __p | bytes;
        __p | ra;
        __p | pe;
        packClosure(__p);
      }
      virtual ~sendDataHandler_3_closure() {
      }
      PUPable_decl(SINGLE_ARG(sendDataHandler_3_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_BufferChares::monitorRead_4_closure : public SDAG::Closure {
      

      monitorRead_4_closure() {
        init();
      }
      monitorRead_4_closure(CkMigrateMessage*) {
        init();
      }
            void pup(PUP::er& __p) {
        packClosure(__p);
      }
      virtual ~monitorRead_4_closure() {
      }
      PUPable_decl(SINGLE_ARG(monitorRead_4_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_BufferChares::bufferReady_5_closure : public SDAG::Closure {
      

      bufferReady_5_closure() {
        init();
      }
      bufferReady_5_closure(CkMigrateMessage*) {
        init();
      }
            void pup(PUP::er& __p) {
        packClosure(__p);
      }
      virtual ~bufferReady_5_closure() {
      }
      PUPable_decl(SINGLE_ARG(bufferReady_5_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY

    struct Closure_BufferChares::printTime_6_closure : public SDAG::Closure {
            double time_taken;


      printTime_6_closure() {
        init();
      }
      printTime_6_closure(CkMigrateMessage*) {
        init();
      }
            double & getP0() { return time_taken;}
      void pup(PUP::er& __p) {
        __p | time_taken;
        packClosure(__p);
      }
      virtual ~printTime_6_closure() {
      }
      PUPable_decl(SINGLE_ARG(printTime_6_closure));
    };
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */


/* ---------------- method closures -------------- */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */


} // namespace impl

/* ---------------- method closures -------------- */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */


} // namespace IO

} // namespace Ck


namespace Ck {
namespace IO {
namespace impl {
/* DEFS: readonly CProxy_Director director;
 */
extern CProxy_Director director;
#ifndef CK_TEMPLATES_ONLY
extern "C" void __xlater_roPup_director(void *_impl_pup_er) {
  PUP::er &_impl_p=*(PUP::er *)_impl_pup_er;
  _impl_p|director;
}
#endif /* CK_TEMPLATES_ONLY */

/* DEFS: mainchare Director: Chare{
Director(CkArgMsg* impl_msg);
void openFile(const std::string &name, const CkCallback &opened, const Options &opts);
void fileOpened(const FileToken &file);
void sessionComplete(const FileToken &file);
void closeReadSession(const Session &impl_noname_0, const CkCallback &impl_noname_1);
void prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready);
void prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const std::vector<int> &pes_to_map);
void prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const CkCallback &complete);
void prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const char *commitData, const size_t &commitBytes, const size_t &commitOffset, const CkCallback &complete);
void sessionReady(CkReductionMsg* impl_msg);
void sessionDone(CkReductionMsg* impl_msg);
void close(const FileToken &token, const CkCallback &closed);
void addSessionReadAssemblerFinished(CkReductionMsg* impl_msg);
Director(CkMigrateMessage* impl_msg);
};
 */
#ifndef CK_TEMPLATES_ONLY
 int CkIndex_Director::__idx=0;
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
/* DEFS: Director(CkArgMsg* impl_msg);
 */
CkChareID CProxy_Director::ckNew(CkArgMsg* impl_msg, int impl_onPE)
{
  CkChareID impl_ret;
  CkCreateChare(CkIndex_Director::__idx, CkIndex_Director::idx_Director_CkArgMsg(), impl_msg, &impl_ret, impl_onPE);
  return impl_ret;
}
void CProxy_Director::ckNew(CkArgMsg* impl_msg, CkChareID* pcid, int impl_onPE)
{
  CkCreateChare(CkIndex_Director::__idx, CkIndex_Director::idx_Director_CkArgMsg(), impl_msg, pcid, impl_onPE);
}

// Entry point registration function
int CkIndex_Director::reg_Director_CkArgMsg() {
  int epidx = CkRegisterEp("Director(CkArgMsg* impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_Director_CkArgMsg), CMessage_CkArgMsg::__idx, __idx, 0);
  CkRegisterMessagePupFn(epidx, (CkMessagePupFn)CkArgMsg::ckDebugPup);
  return epidx;
}

void CkIndex_Director::_call_Director_CkArgMsg(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  new (impl_obj_void) Director((CkArgMsg*)impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void openFile(const std::string &name, const CkCallback &opened, const Options &opts);
 */
void CProxy_Director::openFile(const std::string &name, const CkCallback &opened, const Options &opts, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const std::string &name, const CkCallback &opened, const Options &opts
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)opened;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)opened;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
  }
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_openFile_marshall2(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_openFile_marshall2(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_openFile_marshall2(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_openFile_marshall2() {
  int epidx = CkRegisterEp("openFile(const std::string &name, const CkCallback &opened, const Options &opts)",
      reinterpret_cast<CkCallFnPtr>(_call_openFile_marshall2), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_openFile_marshall2);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_openFile_marshall2);

  return epidx;
}

void CkIndex_Director::_call_openFile_marshall2(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const std::string &name, const CkCallback &opened, const Options &opts*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<std::string> name;
  implP|name;
  PUP::detail::TemporaryObjectHolder<CkCallback> opened;
  implP|opened;
  PUP::detail::TemporaryObjectHolder<Options> opts;
  implP|opts;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->openFile(std::move(name.t), std::move(opened.t), std::move(opts.t));
}
int CkIndex_Director::_callmarshall_openFile_marshall2(char* impl_buf, void* impl_obj_void) {
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const std::string &name, const CkCallback &opened, const Options &opts*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<std::string> name;
  implP|name;
  PUP::detail::TemporaryObjectHolder<CkCallback> opened;
  implP|opened;
  PUP::detail::TemporaryObjectHolder<Options> opts;
  implP|opts;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->openFile(std::move(name.t), std::move(opened.t), std::move(opts.t));
  return implP.size();
}
void CkIndex_Director::_marshallmessagepup_openFile_marshall2(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const std::string &name, const CkCallback &opened, const Options &opts*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<std::string> name;
  implP|name;
  PUP::detail::TemporaryObjectHolder<CkCallback> opened;
  implP|opened;
  PUP::detail::TemporaryObjectHolder<Options> opts;
  implP|opts;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("name");
  implDestP|name;
  if (implDestP.hasComments()) implDestP.comment("opened");
  implDestP|opened;
  if (implDestP.hasComments()) implDestP.comment("opts");
  implDestP|opts;
}
PUPable_def(SINGLE_ARG(Closure_Director::openFile_2_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void fileOpened(const FileToken &file);
 */
void CProxy_Director::fileOpened(const FileToken &file, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const FileToken &file
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
  }
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_fileOpened_marshall3(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_fileOpened_marshall3(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_fileOpened_marshall3(), impl_msg, &ckGetChareID(),0);
  }
}
void CkIndex_Director::_call_redn_wrapper_fileOpened_marshall3(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*> (impl_obj_void);
  char* impl_buf = (char*)((CkReductionMsg*)impl_msg)->getData();
  /*Unmarshall pup'd fields: const FileToken &file*/
  PUP::fromMem implP(impl_buf);
  /* non two-param case */
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->fileOpened(std::move(file.t));
  delete (CkReductionMsg*)impl_msg;
}


// Entry point registration function
int CkIndex_Director::reg_fileOpened_marshall3() {
  int epidx = CkRegisterEp("fileOpened(const FileToken &file)",
      reinterpret_cast<CkCallFnPtr>(_call_fileOpened_marshall3), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_fileOpened_marshall3);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_fileOpened_marshall3);

  return epidx;
}


// Redn wrapper registration function
int CkIndex_Director::reg_redn_wrapper_fileOpened_marshall3() {
  return CkRegisterEp("redn_wrapper_fileOpened(CkReductionMsg *impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_redn_wrapper_fileOpened_marshall3), CkMarshallMsg::__idx, __idx, 0);
}

void CkIndex_Director::_call_fileOpened_marshall3(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->fileOpened(std::move(file.t));
}
int CkIndex_Director::_callmarshall_fileOpened_marshall3(char* impl_buf, void* impl_obj_void) {
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const FileToken &file*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->fileOpened(std::move(file.t));
  return implP.size();
}
void CkIndex_Director::_marshallmessagepup_fileOpened_marshall3(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("file");
  implDestP|file;
}
PUPable_def(SINGLE_ARG(Closure_Director::fileOpened_3_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void sessionComplete(const FileToken &file);
 */
void CProxy_Director::sessionComplete(const FileToken &file, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const FileToken &file
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
  }
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_sessionComplete_marshall4(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_sessionComplete_marshall4(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_sessionComplete_marshall4(), impl_msg, &ckGetChareID(),0);
  }
}
void CkIndex_Director::_call_redn_wrapper_sessionComplete_marshall4(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*> (impl_obj_void);
  char* impl_buf = (char*)((CkReductionMsg*)impl_msg)->getData();
  /*Unmarshall pup'd fields: const FileToken &file*/
  PUP::fromMem implP(impl_buf);
  /* non two-param case */
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->sessionComplete(std::move(file.t));
  delete (CkReductionMsg*)impl_msg;
}


// Entry point registration function
int CkIndex_Director::reg_sessionComplete_marshall4() {
  int epidx = CkRegisterEp("sessionComplete(const FileToken &file)",
      reinterpret_cast<CkCallFnPtr>(_call_sessionComplete_marshall4), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_sessionComplete_marshall4);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_sessionComplete_marshall4);

  return epidx;
}


// Redn wrapper registration function
int CkIndex_Director::reg_redn_wrapper_sessionComplete_marshall4() {
  return CkRegisterEp("redn_wrapper_sessionComplete(CkReductionMsg *impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_redn_wrapper_sessionComplete_marshall4), CkMarshallMsg::__idx, __idx, 0);
}

void CkIndex_Director::_call_sessionComplete_marshall4(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->sessionComplete(std::move(file.t));
}
int CkIndex_Director::_callmarshall_sessionComplete_marshall4(char* impl_buf, void* impl_obj_void) {
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const FileToken &file*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->sessionComplete(std::move(file.t));
  return implP.size();
}
void CkIndex_Director::_marshallmessagepup_sessionComplete_marshall4(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("file");
  implDestP|file;
}
PUPable_def(SINGLE_ARG(Closure_Director::sessionComplete_4_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void closeReadSession(const Session &impl_noname_0, const CkCallback &impl_noname_1);
 */
void CProxy_Director::closeReadSession(const Session &impl_noname_0, const CkCallback &impl_noname_1, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const Session &impl_noname_0, const CkCallback &impl_noname_1
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)impl_noname_0;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)impl_noname_1;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)impl_noname_0;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)impl_noname_1;
  }
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_closeReadSession_marshall5(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_closeReadSession_marshall5(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_closeReadSession_marshall5(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_closeReadSession_marshall5() {
  int epidx = CkRegisterEp("closeReadSession(const Session &impl_noname_0, const CkCallback &impl_noname_1)",
      reinterpret_cast<CkCallFnPtr>(_call_closeReadSession_marshall5), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_closeReadSession_marshall5);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_closeReadSession_marshall5);

  return epidx;
}

void CkIndex_Director::_call_closeReadSession_marshall5(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const Session &impl_noname_0, const CkCallback &impl_noname_1*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<Session> impl_noname_0;
  implP|impl_noname_0;
  PUP::detail::TemporaryObjectHolder<CkCallback> impl_noname_1;
  implP|impl_noname_1;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->closeReadSession(std::move(impl_noname_0.t), std::move(impl_noname_1.t));
}
int CkIndex_Director::_callmarshall_closeReadSession_marshall5(char* impl_buf, void* impl_obj_void) {
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const Session &impl_noname_0, const CkCallback &impl_noname_1*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<Session> impl_noname_0;
  implP|impl_noname_0;
  PUP::detail::TemporaryObjectHolder<CkCallback> impl_noname_1;
  implP|impl_noname_1;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->closeReadSession(std::move(impl_noname_0.t), std::move(impl_noname_1.t));
  return implP.size();
}
void CkIndex_Director::_marshallmessagepup_closeReadSession_marshall5(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const Session &impl_noname_0, const CkCallback &impl_noname_1*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<Session> impl_noname_0;
  implP|impl_noname_0;
  PUP::detail::TemporaryObjectHolder<CkCallback> impl_noname_1;
  implP|impl_noname_1;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("impl_noname_0");
  implDestP|impl_noname_0;
  if (implDestP.hasComments()) implDestP.comment("impl_noname_1");
  implDestP|impl_noname_1;
}
PUPable_def(SINGLE_ARG(Closure_Director::closeReadSession_5_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready);
 */
void CProxy_Director::prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
  }
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_prepareReadSession_marshall6(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_prepareReadSession_marshall6(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_prepareReadSession_marshall6(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_prepareReadSession_marshall6() {
  int epidx = CkRegisterEp("prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready)",
      reinterpret_cast<CkCallFnPtr>(_call_prepareReadSession_marshall6), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_prepareReadSession_marshall6);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_prepareReadSession_marshall6);

  return epidx;
}

void CkIndex_Director::_call_prepareReadSession_marshall6(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  PUP::fromMem implP(impl_buf);
  Closure_Director::prepareReadSession_6_closure* genClosure = new Closure_Director::prepareReadSession_6_closure();
  implP|genClosure->file;
  implP|genClosure->bytes;
  implP|genClosure->offset;
  implP|genClosure->ready;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->_sdag_fnc_prepareReadSession(genClosure);
  genClosure->deref();
}
int CkIndex_Director::_callmarshall_prepareReadSession_marshall6(char* impl_buf, void* impl_obj_void) {
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  PUP::fromMem implP(impl_buf);
  Closure_Director::prepareReadSession_6_closure* genClosure = new Closure_Director::prepareReadSession_6_closure();
  implP|genClosure->file;
  implP|genClosure->bytes;
  implP|genClosure->offset;
  implP|genClosure->ready;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->_sdag_fnc_prepareReadSession(genClosure);
  genClosure->deref();
  return implP.size();
}
void CkIndex_Director::_marshallmessagepup_prepareReadSession_marshall6(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<CkCallback> ready;
  implP|ready;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("file");
  implDestP|file;
  if (implDestP.hasComments()) implDestP.comment("bytes");
  implDestP|bytes;
  if (implDestP.hasComments()) implDestP.comment("offset");
  implDestP|offset;
  if (implDestP.hasComments()) implDestP.comment("ready");
  implDestP|ready;
}
PUPable_def(SINGLE_ARG(Closure_Director::prepareReadSession_6_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const std::vector<int> &pes_to_map);
 */
void CProxy_Director::prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const std::vector<int> &pes_to_map, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const std::vector<int> &pes_to_map
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::vector<int>>::type>::type &)pes_to_map;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::vector<int>>::type>::type &)pes_to_map;
  }
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_prepareReadSession_marshall7(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_prepareReadSession_marshall7(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_prepareReadSession_marshall7(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_prepareReadSession_marshall7() {
  int epidx = CkRegisterEp("prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const std::vector<int> &pes_to_map)",
      reinterpret_cast<CkCallFnPtr>(_call_prepareReadSession_marshall7), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_prepareReadSession_marshall7);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_prepareReadSession_marshall7);

  return epidx;
}

void CkIndex_Director::_call_prepareReadSession_marshall7(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  PUP::fromMem implP(impl_buf);
  Closure_Director::prepareReadSession_7_closure* genClosure = new Closure_Director::prepareReadSession_7_closure();
  implP|genClosure->file;
  implP|genClosure->bytes;
  implP|genClosure->offset;
  implP|genClosure->ready;
  implP|genClosure->pes_to_map;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->_sdag_fnc_prepareReadSession(genClosure);
  genClosure->deref();
}
int CkIndex_Director::_callmarshall_prepareReadSession_marshall7(char* impl_buf, void* impl_obj_void) {
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  PUP::fromMem implP(impl_buf);
  Closure_Director::prepareReadSession_7_closure* genClosure = new Closure_Director::prepareReadSession_7_closure();
  implP|genClosure->file;
  implP|genClosure->bytes;
  implP|genClosure->offset;
  implP|genClosure->ready;
  implP|genClosure->pes_to_map;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->_sdag_fnc_prepareReadSession(genClosure);
  genClosure->deref();
  return implP.size();
}
void CkIndex_Director::_marshallmessagepup_prepareReadSession_marshall7(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const std::vector<int> &pes_to_map*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<CkCallback> ready;
  implP|ready;
  PUP::detail::TemporaryObjectHolder<std::vector<int>> pes_to_map;
  implP|pes_to_map;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("file");
  implDestP|file;
  if (implDestP.hasComments()) implDestP.comment("bytes");
  implDestP|bytes;
  if (implDestP.hasComments()) implDestP.comment("offset");
  implDestP|offset;
  if (implDestP.hasComments()) implDestP.comment("ready");
  implDestP|ready;
  if (implDestP.hasComments()) implDestP.comment("pes_to_map");
  implDestP|pes_to_map;
}
PUPable_def(SINGLE_ARG(Closure_Director::prepareReadSession_7_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const CkCallback &complete);
 */
void CProxy_Director::prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const CkCallback &complete, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const CkCallback &complete
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)complete;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)complete;
  }
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_prepareWriteSession_marshall8(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_prepareWriteSession_marshall8(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_prepareWriteSession_marshall8(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_prepareWriteSession_marshall8() {
  int epidx = CkRegisterEp("prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const CkCallback &complete)",
      reinterpret_cast<CkCallFnPtr>(_call_prepareWriteSession_marshall8), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_prepareWriteSession_marshall8);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_prepareWriteSession_marshall8);

  return epidx;
}

void CkIndex_Director::_call_prepareWriteSession_marshall8(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  PUP::fromMem implP(impl_buf);
  Closure_Director::prepareWriteSession_8_closure* genClosure = new Closure_Director::prepareWriteSession_8_closure();
  implP|genClosure->file;
  implP|genClosure->bytes;
  implP|genClosure->offset;
  implP|genClosure->ready;
  implP|genClosure->complete;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->_sdag_fnc_prepareWriteSession(genClosure);
  genClosure->deref();
}
int CkIndex_Director::_callmarshall_prepareWriteSession_marshall8(char* impl_buf, void* impl_obj_void) {
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  PUP::fromMem implP(impl_buf);
  Closure_Director::prepareWriteSession_8_closure* genClosure = new Closure_Director::prepareWriteSession_8_closure();
  implP|genClosure->file;
  implP|genClosure->bytes;
  implP|genClosure->offset;
  implP|genClosure->ready;
  implP|genClosure->complete;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->_sdag_fnc_prepareWriteSession(genClosure);
  genClosure->deref();
  return implP.size();
}
void CkIndex_Director::_marshallmessagepup_prepareWriteSession_marshall8(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const CkCallback &complete*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<CkCallback> ready;
  implP|ready;
  PUP::detail::TemporaryObjectHolder<CkCallback> complete;
  implP|complete;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("file");
  implDestP|file;
  if (implDestP.hasComments()) implDestP.comment("bytes");
  implDestP|bytes;
  if (implDestP.hasComments()) implDestP.comment("offset");
  implDestP|offset;
  if (implDestP.hasComments()) implDestP.comment("ready");
  implDestP|ready;
  if (implDestP.hasComments()) implDestP.comment("complete");
  implDestP|complete;
}
PUPable_def(SINGLE_ARG(Closure_Director::prepareWriteSession_8_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const char *commitData, const size_t &commitBytes, const size_t &commitOffset, const CkCallback &complete);
 */
void CProxy_Director::prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const char *commitData, const size_t &commitBytes, const size_t &commitOffset, const CkCallback &complete, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const char *commitData, const size_t &commitBytes, const size_t &commitOffset, const CkCallback &complete
  int impl_off=0;
  int impl_arrstart=0;
  int impl_off_commitData, impl_cnt_commitData;
  impl_off_commitData=impl_off=CK_ALIGN(impl_off,sizeof(char));
  impl_off+=(impl_cnt_commitData=sizeof(char)*(commitBytes));
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    implP|impl_off_commitData;
    implP|impl_cnt_commitData;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)commitBytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)commitOffset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)complete;
    impl_arrstart=CK_ALIGN(implP.size(),16);
    impl_off+=impl_arrstart;
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    implP|impl_off_commitData;
    implP|impl_cnt_commitData;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)commitBytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)commitOffset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)complete;
  }
  char *impl_buf=impl_msg->msgBuf+impl_arrstart;
  memcpy(impl_buf+impl_off_commitData,commitData,impl_cnt_commitData);
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_prepareWriteSession_marshall9(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_prepareWriteSession_marshall9(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_prepareWriteSession_marshall9(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_prepareWriteSession_marshall9() {
  int epidx = CkRegisterEp("prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const char *commitData, const size_t &commitBytes, const size_t &commitOffset, const CkCallback &complete)",
      reinterpret_cast<CkCallFnPtr>(_call_prepareWriteSession_marshall9), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_prepareWriteSession_marshall9);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_prepareWriteSession_marshall9);

  return epidx;
}

void CkIndex_Director::_call_prepareWriteSession_marshall9(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  PUP::fromMem implP(impl_buf);
  Closure_Director::prepareWriteSession_9_closure* genClosure = new Closure_Director::prepareWriteSession_9_closure();
  implP|genClosure->file;
  implP|genClosure->bytes;
  implP|genClosure->offset;
  implP|genClosure->ready;
  int impl_off_commitData, impl_cnt_commitData;
  implP|impl_off_commitData;
  implP|impl_cnt_commitData;
  implP|genClosure->commitBytes;
  implP|genClosure->commitOffset;
  implP|genClosure->complete;
  impl_buf+=CK_ALIGN(implP.size(),16);
  genClosure->commitData = (char *)(impl_buf+impl_off_commitData);
  genClosure->_impl_marshall = impl_msg_typed;
  CkReferenceMsg(genClosure->_impl_marshall);
  impl_obj->_sdag_fnc_prepareWriteSession(genClosure);
  genClosure->deref();
}
int CkIndex_Director::_callmarshall_prepareWriteSession_marshall9(char* impl_buf, void* impl_obj_void) {
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  PUP::fromMem implP(impl_buf);
  Closure_Director::prepareWriteSession_9_closure* genClosure = new Closure_Director::prepareWriteSession_9_closure();
  implP|genClosure->file;
  implP|genClosure->bytes;
  implP|genClosure->offset;
  implP|genClosure->ready;
  int impl_off_commitData, impl_cnt_commitData;
  implP|impl_off_commitData;
  implP|impl_cnt_commitData;
  implP|genClosure->commitBytes;
  implP|genClosure->commitOffset;
  implP|genClosure->complete;
  impl_buf+=CK_ALIGN(implP.size(),16);
  genClosure->commitData = (char *)(impl_buf+impl_off_commitData);
  impl_obj->_sdag_fnc_prepareWriteSession(genClosure);
  genClosure->deref();
  return implP.size();
}
void CkIndex_Director::_marshallmessagepup_prepareWriteSession_marshall9(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const char *commitData, const size_t &commitBytes, const size_t &commitOffset, const CkCallback &complete*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<CkCallback> ready;
  implP|ready;
  int impl_off_commitData, impl_cnt_commitData;
  implP|impl_off_commitData;
  implP|impl_cnt_commitData;
  PUP::detail::TemporaryObjectHolder<size_t> commitBytes;
  implP|commitBytes;
  PUP::detail::TemporaryObjectHolder<size_t> commitOffset;
  implP|commitOffset;
  PUP::detail::TemporaryObjectHolder<CkCallback> complete;
  implP|complete;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  char *commitData=(char *)(impl_buf+impl_off_commitData);
  if (implDestP.hasComments()) implDestP.comment("file");
  implDestP|file;
  if (implDestP.hasComments()) implDestP.comment("bytes");
  implDestP|bytes;
  if (implDestP.hasComments()) implDestP.comment("offset");
  implDestP|offset;
  if (implDestP.hasComments()) implDestP.comment("ready");
  implDestP|ready;
  if (implDestP.hasComments()) implDestP.comment("commitData");
  implDestP.synchronize(PUP::sync_begin_array);
  for (int impl_i=0;impl_i*(sizeof(*commitData))<impl_cnt_commitData;impl_i++) {
    implDestP.synchronize(PUP::sync_item);
    implDestP|commitData[impl_i];
  }
  implDestP.synchronize(PUP::sync_end_array);
  if (implDestP.hasComments()) implDestP.comment("commitBytes");
  implDestP|commitBytes;
  if (implDestP.hasComments()) implDestP.comment("commitOffset");
  implDestP|commitOffset;
  if (implDestP.hasComments()) implDestP.comment("complete");
  implDestP|complete;
}
PUPable_def(SINGLE_ARG(Closure_Director::prepareWriteSession_9_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void sessionReady(CkReductionMsg* impl_msg);
 */
void CProxy_Director::sessionReady(CkReductionMsg* impl_msg)
{
  ckCheck();
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_sessionReady_CkReductionMsg(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_sessionReady_CkReductionMsg(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_sessionReady_CkReductionMsg(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_sessionReady_CkReductionMsg() {
  int epidx = CkRegisterEp("sessionReady(CkReductionMsg* impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_sessionReady_CkReductionMsg), CMessage_CkReductionMsg::__idx, __idx, 0);
  CkRegisterMessagePupFn(epidx, (CkMessagePupFn)CkReductionMsg::ckDebugPup);
  return epidx;
}

void CkIndex_Director::_call_sessionReady_CkReductionMsg(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  impl_obj->sessionReady((CkReductionMsg*)impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void sessionDone(CkReductionMsg* impl_msg);
 */
void CProxy_Director::sessionDone(CkReductionMsg* impl_msg)
{
  ckCheck();
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_sessionDone_CkReductionMsg(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_sessionDone_CkReductionMsg(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_sessionDone_CkReductionMsg(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_sessionDone_CkReductionMsg() {
  int epidx = CkRegisterEp("sessionDone(CkReductionMsg* impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_sessionDone_CkReductionMsg), CMessage_CkReductionMsg::__idx, __idx, 0);
  CkRegisterMessagePupFn(epidx, (CkMessagePupFn)CkReductionMsg::ckDebugPup);
  return epidx;
}

void CkIndex_Director::_call_sessionDone_CkReductionMsg(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  impl_obj->sessionDone((CkReductionMsg*)impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void close(const FileToken &token, const CkCallback &closed);
 */
void CProxy_Director::close(const FileToken &token, const CkCallback &closed, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const FileToken &token, const CkCallback &closed
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
  }
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_close_marshall12(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_close_marshall12(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_close_marshall12(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_close_marshall12() {
  int epidx = CkRegisterEp("close(const FileToken &token, const CkCallback &closed)",
      reinterpret_cast<CkCallFnPtr>(_call_close_marshall12), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_close_marshall12);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_close_marshall12);

  return epidx;
}

void CkIndex_Director::_call_close_marshall12(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &token, const CkCallback &closed*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> token;
  implP|token;
  PUP::detail::TemporaryObjectHolder<CkCallback> closed;
  implP|closed;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->close(std::move(token.t), std::move(closed.t));
}
int CkIndex_Director::_callmarshall_close_marshall12(char* impl_buf, void* impl_obj_void) {
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const FileToken &token, const CkCallback &closed*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> token;
  implP|token;
  PUP::detail::TemporaryObjectHolder<CkCallback> closed;
  implP|closed;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->close(std::move(token.t), std::move(closed.t));
  return implP.size();
}
void CkIndex_Director::_marshallmessagepup_close_marshall12(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &token, const CkCallback &closed*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> token;
  implP|token;
  PUP::detail::TemporaryObjectHolder<CkCallback> closed;
  implP|closed;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("token");
  implDestP|token;
  if (implDestP.hasComments()) implDestP.comment("closed");
  implDestP|closed;
}
PUPable_def(SINGLE_ARG(Closure_Director::close_12_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void addSessionReadAssemblerFinished(CkReductionMsg* impl_msg);
 */
void CProxy_Director::addSessionReadAssemblerFinished(CkReductionMsg* impl_msg)
{
  ckCheck();
  if (ckIsDelegated()) {
    int destPE=CkChareMsgPrep(CkIndex_Director::idx_addSessionReadAssemblerFinished_CkReductionMsg(), impl_msg, &ckGetChareID());
    if (destPE!=-1) ckDelegatedTo()->ChareSend(ckDelegatedPtr(),CkIndex_Director::idx_addSessionReadAssemblerFinished_CkReductionMsg(), impl_msg, &ckGetChareID(),destPE);
  } else {
    CkSendMsg(CkIndex_Director::idx_addSessionReadAssemblerFinished_CkReductionMsg(), impl_msg, &ckGetChareID(),0);
  }
}

// Entry point registration function
int CkIndex_Director::reg_addSessionReadAssemblerFinished_CkReductionMsg() {
  int epidx = CkRegisterEp("addSessionReadAssemblerFinished(CkReductionMsg* impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_addSessionReadAssemblerFinished_CkReductionMsg), CMessage_CkReductionMsg::__idx, __idx, 0);
  CkRegisterMessagePupFn(epidx, (CkMessagePupFn)CkReductionMsg::ckDebugPup);
  return epidx;
}

void CkIndex_Director::_call_addSessionReadAssemblerFinished_CkReductionMsg(void* impl_msg, void* impl_obj_void)
{
  Director* impl_obj = static_cast<Director*>(impl_obj_void);
  impl_obj->addSessionReadAssemblerFinished((CkReductionMsg*)impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: Director(CkMigrateMessage* impl_msg);
 */

// Entry point registration function
int CkIndex_Director::reg_Director_CkMigrateMessage() {
  int epidx = CkRegisterEp("Director(CkMigrateMessage* impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_Director_CkMigrateMessage), 0, __idx, 0);
  return epidx;
}

void CkIndex_Director::_call_Director_CkMigrateMessage(void* impl_msg, void* impl_obj_void)
{
  new (impl_obj_void) Director((CkMigrateMessage*)impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void CkIndex_Director::__register(const char *s, size_t size) {
  __idx = CkRegisterChare(s, size, TypeMainChare);
  CkRegisterBase(__idx, CkIndex_Chare::__idx);
  // REG: Director(CkArgMsg* impl_msg);
  idx_Director_CkArgMsg();
  CkRegisterMainChare(__idx, idx_Director_CkArgMsg());

  // REG: void openFile(const std::string &name, const CkCallback &opened, const Options &opts);
  idx_openFile_marshall2();

  // REG: void fileOpened(const FileToken &file);
  idx_fileOpened_marshall3();
  idx_redn_wrapper_fileOpened_marshall3();

  // REG: void sessionComplete(const FileToken &file);
  idx_sessionComplete_marshall4();
  idx_redn_wrapper_sessionComplete_marshall4();

  // REG: void closeReadSession(const Session &impl_noname_0, const CkCallback &impl_noname_1);
  idx_closeReadSession_marshall5();

  // REG: void prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready);
  idx_prepareReadSession_marshall6();

  // REG: void prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const std::vector<int> &pes_to_map);
  idx_prepareReadSession_marshall7();

  // REG: void prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const CkCallback &complete);
  idx_prepareWriteSession_marshall8();

  // REG: void prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const char *commitData, const size_t &commitBytes, const size_t &commitOffset, const CkCallback &complete);
  idx_prepareWriteSession_marshall9();

  // REG: void sessionReady(CkReductionMsg* impl_msg);
  idx_sessionReady_CkReductionMsg();

  // REG: void sessionDone(CkReductionMsg* impl_msg);
  idx_sessionDone_CkReductionMsg();

  // REG: void close(const FileToken &token, const CkCallback &closed);
  idx_close_marshall12();

  // REG: void addSessionReadAssemblerFinished(CkReductionMsg* impl_msg);
  idx_addSessionReadAssemblerFinished_CkReductionMsg();

  // REG: Director(CkMigrateMessage* impl_msg);
  idx_Director_CkMigrateMessage();
  CkRegisterMigCtor(__idx, idx_Director_CkMigrateMessage());

  Director::__sdag_register(); // Potentially missing Director_SDAG_CODE in your class definition?
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
void Director::prepareReadSession(FileToken file, size_t bytes, size_t offset, CkCallback ready){
  CkPrintf("Error> Direct call to SDAG entry method \'%s::%s\'!\n", "Director", "prepareReadSession(FileToken file, size_t bytes, size_t offset, CkCallback ready)"); 
  CkAbort("Direct SDAG call is not allowed for SDAG entry methods having when constructs. Call such SDAG methods using a proxy"); 
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_fnc_prepareReadSession(FileToken file, size_t bytes, size_t offset, CkCallback ready){
  Closure_Director::prepareReadSession_6_closure* genClosure = new Closure_Director::prepareReadSession_6_closure();
  genClosure->getP0() = file;
  genClosure->getP1() = bytes;
  genClosure->getP2() = offset;
  genClosure->getP3() = ready;
  _sdag_fnc_prepareReadSession(genClosure);
  genClosure->deref();
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_fnc_prepareReadSession(Closure_Director::prepareReadSession_6_closure* gen0) {
  _TRACE_END_EXECUTE(); 
  if (!__dep.get()) _sdag_init();
  _slist_0(gen0);
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::prepareReadSession_end(Closure_Director::prepareReadSession_6_closure* gen0) {
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_slist_0(Closure_Director::prepareReadSession_6_closure* gen0) {
  _serial_0(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_slist_0_end(Closure_Director::prepareReadSession_6_closure* gen0) {
  prepareReadSession_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_0(Closure_Director::prepareReadSession_6_closure* gen0) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_0()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    { // begin serial block
#line 34 "ckio.ci"
prepareReadSessionHelper(file, bytes, offset, ready, std::vector<int>());
  
#line 2075 "CkIO_impl.def.h"
    } // end serial block
  }
  _TRACE_END_EXECUTE(); 
  _when_0(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_0(Closure_Director::prepareReadSession_6_closure* gen0) {
  CMK_REFNUM_TYPE refnum_0;
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    {
      refnum_0 = files[file].sessionID;
    }
  }
  return _when_0(gen0, refnum_0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_0(Closure_Director::prepareReadSession_6_closure* gen0, int refnum_0) {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(0, true, refnum_0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    _serial_1(gen0, static_cast<CkReductionMsg*>(static_cast<SDAG::MsgClosure*>(buf0->cl)->msg));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(0);
    c->addClosure(gen0);
    c->entries.push_back(0);
    c->refnums.push_back(refnum_0);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_when_0_end(Closure_Director::prepareReadSession_6_closure* gen0, CkReductionMsg* gen1) {
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    {
      CkReductionMsg*& m = gen1;
      CmiFree(UsrToEnv(m));
    }
  }
  _when_1(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_1(Closure_Director::prepareReadSession_6_closure* gen0, CkReductionMsg* gen1) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_1()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    {
      CkReductionMsg*& m = gen1;
      { // begin serial block
#line 37 "ckio.ci"

    delete m;
    Session s(file, bytes, offset, files[file].read_session);
    CProxy_ReadAssembler ra = CProxy_ReadAssembler::ckNew(s);
    managers.addSessionReadAssemblerMapping(s, ra, ready);
  
#line 2156 "CkIO_impl.def.h"
      } // end serial block
    }
  }
  _TRACE_END_EXECUTE(); 
  _when_0_end(gen0, gen1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_1(Closure_Director::prepareReadSession_6_closure* gen0) {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(1, false, 0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    _serial_2(gen0, static_cast<CkReductionMsg*>(static_cast<SDAG::MsgClosure*>(buf0->cl)->msg));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(1);
    c->addClosure(gen0);
    c->anyEntries.push_back(1);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_when_1_end(Closure_Director::prepareReadSession_6_closure* gen0, CkReductionMsg* gen1) {
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    {
      CkReductionMsg*& msg = gen1;
      CmiFree(UsrToEnv(msg));
    }
  }
  _slist_0_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_2(Closure_Director::prepareReadSession_6_closure* gen0, CkReductionMsg* gen1) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_2()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    {
      CkReductionMsg*& msg = gen1;
      { // begin serial block
#line 44 "ckio.ci"

    ready.send(
        new SessionReadyMsg(Session(file, bytes, offset, files[file].read_session)));
    delete msg;
  
#line 2219 "CkIO_impl.def.h"
      } // end serial block
    }
  }
  _TRACE_END_EXECUTE(); 
  _when_1_end(gen0, gen1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::prepareReadSession(FileToken file, size_t bytes, size_t offset, CkCallback ready, std::vector<int> pes_to_map){
  CkPrintf("Error> Direct call to SDAG entry method \'%s::%s\'!\n", "Director", "prepareReadSession(FileToken file, size_t bytes, size_t offset, CkCallback ready, std::vector<int> pes_to_map)"); 
  CkAbort("Direct SDAG call is not allowed for SDAG entry methods having when constructs. Call such SDAG methods using a proxy"); 
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_fnc_prepareReadSession(FileToken file, size_t bytes, size_t offset, CkCallback ready, std::vector<int> pes_to_map){
  Closure_Director::prepareReadSession_7_closure* genClosure = new Closure_Director::prepareReadSession_7_closure();
  genClosure->getP0() = file;
  genClosure->getP1() = bytes;
  genClosure->getP2() = offset;
  genClosure->getP3() = ready;
  genClosure->getP4() = pes_to_map;
  _sdag_fnc_prepareReadSession(genClosure);
  genClosure->deref();
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_fnc_prepareReadSession(Closure_Director::prepareReadSession_7_closure* gen0) {
  _TRACE_END_EXECUTE(); 
  if (!__dep.get()) _sdag_init();
  _slist_1(gen0);
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::prepareReadSession_end(Closure_Director::prepareReadSession_7_closure* gen0) {
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_slist_1(Closure_Director::prepareReadSession_7_closure* gen0) {
  _serial_3(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_slist_1_end(Closure_Director::prepareReadSession_7_closure* gen0) {
  prepareReadSession_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_3(Closure_Director::prepareReadSession_7_closure* gen0) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_3()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    std::vector<int>& pes_to_map = gen0->getP4();
    { // begin serial block
#line 52 "ckio.ci"
prepareReadSessionHelper(file, bytes, offset, ready, pes_to_map);
  
#line 2292 "CkIO_impl.def.h"
    } // end serial block
  }
  _TRACE_END_EXECUTE(); 
  _when_2(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_2(Closure_Director::prepareReadSession_7_closure* gen0) {
  CMK_REFNUM_TYPE refnum_0;
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    std::vector<int>& pes_to_map = gen0->getP4();
    {
      refnum_0 = files[file].sessionID;
    }
  }
  return _when_2(gen0, refnum_0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_2(Closure_Director::prepareReadSession_7_closure* gen0, int refnum_0) {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(0, true, refnum_0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    _serial_4(gen0, static_cast<CkReductionMsg*>(static_cast<SDAG::MsgClosure*>(buf0->cl)->msg));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(2);
    c->addClosure(gen0);
    c->entries.push_back(0);
    c->refnums.push_back(refnum_0);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_when_2_end(Closure_Director::prepareReadSession_7_closure* gen0, CkReductionMsg* gen1) {
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    std::vector<int>& pes_to_map = gen0->getP4();
    {
      CkReductionMsg*& m = gen1;
      CmiFree(UsrToEnv(m));
    }
  }
  _when_3(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_4(Closure_Director::prepareReadSession_7_closure* gen0, CkReductionMsg* gen1) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_4()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    std::vector<int>& pes_to_map = gen0->getP4();
    {
      CkReductionMsg*& m = gen1;
      { // begin serial block
#line 55 "ckio.ci"

    delete m;
    Session s(file, bytes, offset, files[file].read_session);
    CProxy_ReadAssembler ra = CProxy_ReadAssembler::ckNew(s);
    managers.addSessionReadAssemblerMapping(s, ra, ready);
  
#line 2376 "CkIO_impl.def.h"
      } // end serial block
    }
  }
  _TRACE_END_EXECUTE(); 
  _when_2_end(gen0, gen1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_3(Closure_Director::prepareReadSession_7_closure* gen0) {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(1, false, 0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    _serial_5(gen0, static_cast<CkReductionMsg*>(static_cast<SDAG::MsgClosure*>(buf0->cl)->msg));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(3);
    c->addClosure(gen0);
    c->anyEntries.push_back(1);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_when_3_end(Closure_Director::prepareReadSession_7_closure* gen0, CkReductionMsg* gen1) {
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    std::vector<int>& pes_to_map = gen0->getP4();
    {
      CkReductionMsg*& msg = gen1;
      CmiFree(UsrToEnv(msg));
    }
  }
  _slist_1_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_5(Closure_Director::prepareReadSession_7_closure* gen0, CkReductionMsg* gen1) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_5()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    std::vector<int>& pes_to_map = gen0->getP4();
    {
      CkReductionMsg*& msg = gen1;
      { // begin serial block
#line 62 "ckio.ci"

    ready.send(
        new SessionReadyMsg(Session(file, bytes, offset, files[file].read_session)));
    delete msg;
  
#line 2441 "CkIO_impl.def.h"
      } // end serial block
    }
  }
  _TRACE_END_EXECUTE(); 
  _when_3_end(gen0, gen1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::prepareWriteSession(FileToken file, size_t bytes, size_t offset, CkCallback ready, CkCallback complete){
  CkPrintf("Error> Direct call to SDAG entry method \'%s::%s\'!\n", "Director", "prepareWriteSession(FileToken file, size_t bytes, size_t offset, CkCallback ready, CkCallback complete)"); 
  CkAbort("Direct SDAG call is not allowed for SDAG entry methods having when constructs. Call such SDAG methods using a proxy"); 
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_fnc_prepareWriteSession(FileToken file, size_t bytes, size_t offset, CkCallback ready, CkCallback complete){
  Closure_Director::prepareWriteSession_8_closure* genClosure = new Closure_Director::prepareWriteSession_8_closure();
  genClosure->getP0() = file;
  genClosure->getP1() = bytes;
  genClosure->getP2() = offset;
  genClosure->getP3() = ready;
  genClosure->getP4() = complete;
  _sdag_fnc_prepareWriteSession(genClosure);
  genClosure->deref();
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_fnc_prepareWriteSession(Closure_Director::prepareWriteSession_8_closure* gen0) {
  _TRACE_END_EXECUTE(); 
  if (!__dep.get()) _sdag_init();
  _slist_2(gen0);
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::prepareWriteSession_end(Closure_Director::prepareWriteSession_8_closure* gen0) {
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_slist_2(Closure_Director::prepareWriteSession_8_closure* gen0) {
  _serial_6(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_slist_2_end(Closure_Director::prepareWriteSession_8_closure* gen0) {
  prepareWriteSession_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_6(Closure_Director::prepareWriteSession_8_closure* gen0) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_6()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    CkCallback& complete = gen0->getP4();
    { // begin serial block
#line 70 "ckio.ci"
prepareWriteSession_helper(file, bytes, offset, ready, complete);

#line 2514 "CkIO_impl.def.h"
    } // end serial block
  }
  _TRACE_END_EXECUTE(); 
  _when_4(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_4(Closure_Director::prepareWriteSession_8_closure* gen0) {
  CMK_REFNUM_TYPE refnum_0;
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    CkCallback& complete = gen0->getP4();
    {
      refnum_0 = files[file].sessionID;
    }
  }
  return _when_4(gen0, refnum_0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_4(Closure_Director::prepareWriteSession_8_closure* gen0, int refnum_0) {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(0, true, refnum_0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    _serial_7(gen0, static_cast<CkReductionMsg*>(static_cast<SDAG::MsgClosure*>(buf0->cl)->msg));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(4);
    c->addClosure(gen0);
    c->entries.push_back(0);
    c->refnums.push_back(refnum_0);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_when_4_end(Closure_Director::prepareWriteSession_8_closure* gen0, CkReductionMsg* gen1) {
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    CkCallback& complete = gen0->getP4();
    {
      CkReductionMsg*& m = gen1;
      CmiFree(UsrToEnv(m));
    }
  }
  _slist_2_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_7(Closure_Director::prepareWriteSession_8_closure* gen0, CkReductionMsg* gen1) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_7()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    CkCallback& complete = gen0->getP4();
    {
      CkReductionMsg*& m = gen1;
      { // begin serial block
#line 73 "ckio.ci"

  delete m;
  ready.send(new SessionReadyMsg(Session(file, bytes, offset, files[file].session)));

#line 2596 "CkIO_impl.def.h"
      } // end serial block
    }
  }
  _TRACE_END_EXECUTE(); 
  _when_4_end(gen0, gen1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::prepareWriteSession(FileToken file, size_t bytes, size_t offset, CkCallback ready, char * commitData, size_t commitBytes, size_t commitOffset, CkCallback complete){
  CkPrintf("Error> Direct call to SDAG entry method \'%s::%s\'!\n", "Director", "prepareWriteSession(FileToken file, size_t bytes, size_t offset, CkCallback ready, char * commitData, size_t commitBytes, size_t commitOffset, CkCallback complete)"); 
  CkAbort("Direct SDAG call is not allowed for SDAG entry methods having when constructs. Call such SDAG methods using a proxy"); 
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_fnc_prepareWriteSession(FileToken file, size_t bytes, size_t offset, CkCallback ready, char * commitData, size_t commitBytes, size_t commitOffset, CkCallback complete){
  Closure_Director::prepareWriteSession_9_closure* genClosure = new Closure_Director::prepareWriteSession_9_closure();
  genClosure->getP0() = file;
  genClosure->getP1() = bytes;
  genClosure->getP2() = offset;
  genClosure->getP3() = ready;
  genClosure->getP4() = commitData;
  genClosure->getP5() = commitBytes;
  genClosure->getP6() = commitOffset;
  genClosure->getP7() = complete;
  _sdag_fnc_prepareWriteSession(genClosure);
  genClosure->deref();
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_fnc_prepareWriteSession(Closure_Director::prepareWriteSession_9_closure* gen0) {
  _TRACE_END_EXECUTE(); 
  if (!__dep.get()) _sdag_init();
  _slist_3(gen0);
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::prepareWriteSession_end(Closure_Director::prepareWriteSession_9_closure* gen0) {
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_slist_3(Closure_Director::prepareWriteSession_9_closure* gen0) {
  _serial_8(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_slist_3_end(Closure_Director::prepareWriteSession_9_closure* gen0) {
  prepareWriteSession_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_8(Closure_Director::prepareWriteSession_9_closure* gen0) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_8()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    char*& commitData = gen0->getP4();
    size_t& commitBytes = gen0->getP5();
    size_t& commitOffset = gen0->getP6();
    CkCallback& complete = gen0->getP7();
    { // begin serial block
#line 83 "ckio.ci"
CkCallback committed(CkIndex_Director::sessionDone(NULL), thisProxy);
committed.setRefnum(++sessionID);
prepareWriteSession_helper(file, bytes, offset, ready, committed);

#line 2677 "CkIO_impl.def.h"
    } // end serial block
  }
  _TRACE_END_EXECUTE(); 
  _when_5(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_5(Closure_Director::prepareWriteSession_9_closure* gen0) {
  CMK_REFNUM_TYPE refnum_0;
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    char*& commitData = gen0->getP4();
    size_t& commitBytes = gen0->getP5();
    size_t& commitOffset = gen0->getP6();
    CkCallback& complete = gen0->getP7();
    {
      refnum_0 = files[file].sessionID;
    }
  }
  return _when_5(gen0, refnum_0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_5(Closure_Director::prepareWriteSession_9_closure* gen0, int refnum_0) {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(0, true, refnum_0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    _serial_9(gen0, static_cast<CkReductionMsg*>(static_cast<SDAG::MsgClosure*>(buf0->cl)->msg));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(5);
    c->addClosure(gen0);
    c->entries.push_back(0);
    c->refnums.push_back(refnum_0);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_when_5_end(Closure_Director::prepareWriteSession_9_closure* gen0, CkReductionMsg* gen1) {
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    char*& commitData = gen0->getP4();
    size_t& commitBytes = gen0->getP5();
    size_t& commitOffset = gen0->getP6();
    CkCallback& complete = gen0->getP7();
    {
      CkReductionMsg*& m = gen1;
      CmiFree(UsrToEnv(m));
    }
  }
  _when_6(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_9(Closure_Director::prepareWriteSession_9_closure* gen0, CkReductionMsg* gen1) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_9()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    char*& commitData = gen0->getP4();
    size_t& commitBytes = gen0->getP5();
    size_t& commitOffset = gen0->getP6();
    CkCallback& complete = gen0->getP7();
    {
      CkReductionMsg*& m = gen1;
      { // begin serial block
#line 88 "ckio.ci"

  delete m;
  ready.send(new SessionReadyMsg(Session(file, bytes, offset, files[file].session)));

#line 2768 "CkIO_impl.def.h"
      } // end serial block
    }
  }
  _TRACE_END_EXECUTE(); 
  _when_5_end(gen0, gen1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_6(Closure_Director::prepareWriteSession_9_closure* gen0) {
  CMK_REFNUM_TYPE refnum_0;
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    char*& commitData = gen0->getP4();
    size_t& commitBytes = gen0->getP5();
    size_t& commitOffset = gen0->getP6();
    CkCallback& complete = gen0->getP7();
    {
      refnum_0 = files[file].sessionID;
    }
  }
  return _when_6(gen0, refnum_0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Director::_when_6(Closure_Director::prepareWriteSession_9_closure* gen0, int refnum_0) {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(2, true, refnum_0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    _serial_10(gen0, static_cast<CkReductionMsg*>(static_cast<SDAG::MsgClosure*>(buf0->cl)->msg));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(6);
    c->addClosure(gen0);
    c->entries.push_back(2);
    c->refnums.push_back(refnum_0);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_when_6_end(Closure_Director::prepareWriteSession_9_closure* gen0, CkReductionMsg* gen1) {
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    char*& commitData = gen0->getP4();
    size_t& commitBytes = gen0->getP5();
    size_t& commitOffset = gen0->getP6();
    CkCallback& complete = gen0->getP7();
    {
      CkReductionMsg*& m = gen1;
      CmiFree(UsrToEnv(m));
    }
  }
  _slist_3_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_serial_10(Closure_Director::prepareWriteSession_9_closure* gen0, CkReductionMsg* gen1) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Director_serial_10()), CkMyPe(), 0, NULL, this); 
  {
    FileToken& file = gen0->getP0();
    size_t& bytes = gen0->getP1();
    size_t& offset = gen0->getP2();
    CkCallback& ready = gen0->getP3();
    char*& commitData = gen0->getP4();
    size_t& commitBytes = gen0->getP5();
    size_t& commitOffset = gen0->getP6();
    CkCallback& complete = gen0->getP7();
    {
      CkReductionMsg*& m = gen1;
      { // begin serial block
#line 93 "ckio.ci"

  delete m;
  impl::FileInfo* info = CkpvAccess(manager)->get(file);
  CmiInt8 ret = CmiPwrite(info->fd, commitData, commitBytes, commitOffset);
  if (ret != commitBytes)
    fatalError("Commit write failed", info->name);
  complete.send(CkReductionMsg::buildNew(0, NULL, CkReduction::nop));

#line 2864 "CkIO_impl.def.h"
      } // end serial block
    }
  }
  _TRACE_END_EXECUTE(); 
  _when_6_end(gen0, gen1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::sessionReady(CkReductionMsg* m_msg){
  if (!__dep.get()) _sdag_init();
  CkReferenceMsg(m_msg);
  __dep->pushBuffer(0, new SDAG::MsgClosure(m_msg));
  SDAG::Continuation* c = __dep->tryFindContinuation(0);
  if (c) {
    _TRACE_END_EXECUTE(); 
    switch(c->whenID) {
    case 0:
      _when_0(
        static_cast<Closure_Director::prepareReadSession_6_closure*>(c->closure[0]), 
        c->refnums[0]
      );
    break;
    case 2:
      _when_2(
        static_cast<Closure_Director::prepareReadSession_7_closure*>(c->closure[0]), 
        c->refnums[0]
      );
    break;
    case 4:
      _when_4(
        static_cast<Closure_Director::prepareWriteSession_8_closure*>(c->closure[0]), 
        c->refnums[0]
      );
    break;
    case 5:
      _when_5(
        static_cast<Closure_Director::prepareWriteSession_9_closure*>(c->closure[0]), 
        c->refnums[0]
      );
    break;
    }
    _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
    delete c;
  }
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::addSessionReadAssemblerFinished(CkReductionMsg* msg_msg){
  if (!__dep.get()) _sdag_init();
  CkReferenceMsg(msg_msg);
  __dep->pushBuffer(1, new SDAG::MsgClosure(msg_msg));
  SDAG::Continuation* c = __dep->tryFindContinuation(1);
  if (c) {
    _TRACE_END_EXECUTE(); 
    switch(c->whenID) {
    case 1:
      _when_1(
        static_cast<Closure_Director::prepareReadSession_6_closure*>(c->closure[0])
      );
    break;
    case 3:
      _when_3(
        static_cast<Closure_Director::prepareReadSession_7_closure*>(c->closure[0])
      );
    break;
    }
    _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
    delete c;
  }
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::sessionDone(CkReductionMsg* m_msg){
  if (!__dep.get()) _sdag_init();
  CkReferenceMsg(m_msg);
  __dep->pushBuffer(2, new SDAG::MsgClosure(m_msg));
  SDAG::Continuation* c = __dep->tryFindContinuation(2);
  if (c) {
    _TRACE_END_EXECUTE(); 
    _when_6(
      static_cast<Closure_Director::prepareWriteSession_9_closure*>(c->closure[0]), 
      c->refnums[0]
    );
    _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
    delete c;
  }
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_init() { // Potentially missing Director_SDAG_CODE in your class definition?
  __dep.reset(new SDAG::Dependency(3,7));
  __dep->addDepends(0,0);
  __dep->addDepends(2,0);
  __dep->addDepends(4,0);
  __dep->addDepends(5,0);
  __dep->addDepends(1,1);
  __dep->addDepends(3,1);
  __dep->addDepends(6,2);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::__sdag_init() { // Potentially missing Director_SDAG_CODE in your class definition?
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Director::_sdag_pup(PUP::er &p) {  // Potentially missing Director_SDAG_CODE in your class definition?
  p|__dep;
}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Director::__sdag_register() { // Potentially missing Director_SDAG_CODE in your class definition?
  (void)_sdag_idx_Director_serial_0();
  (void)_sdag_idx_Director_serial_1();
  (void)_sdag_idx_Director_serial_2();
  (void)_sdag_idx_Director_serial_3();
  (void)_sdag_idx_Director_serial_4();
  (void)_sdag_idx_Director_serial_5();
  (void)_sdag_idx_Director_serial_6();
  (void)_sdag_idx_Director_serial_7();
  (void)_sdag_idx_Director_serial_8();
  (void)_sdag_idx_Director_serial_9();
  (void)_sdag_idx_Director_serial_10();
  PUPable_reg(SINGLE_ARG(Closure_Director::openFile_2_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::fileOpened_3_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::sessionComplete_4_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::closeReadSession_5_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::prepareReadSession_6_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::prepareReadSession_7_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::prepareWriteSession_8_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::prepareWriteSession_9_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::close_12_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::openFile_2_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::fileOpened_3_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::sessionComplete_4_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::closeReadSession_5_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::prepareReadSession_6_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::prepareReadSession_7_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::prepareWriteSession_8_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::prepareWriteSession_9_closure));
  PUPable_reg(SINGLE_ARG(Closure_Director::close_12_closure));
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_0() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_0();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_0() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_0", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_1() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_1();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_1() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_1", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_2() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_2();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_2() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_2", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_3() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_3();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_3() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_3", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_4() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_4();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_4() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_4", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_5() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_5();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_5() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_5", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_6() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_6();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_6() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_6", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_7() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_7();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_7() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_7", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_8() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_8();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_8() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_8", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_9() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_9();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_9() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_9", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_idx_Director_serial_10() { // Potentially missing Director_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Director_serial_10();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Director::_sdag_reg_Director_serial_10() { // Potentially missing Director_SDAG_CODE in your class definition?
  return CkRegisterEp("Director_serial_10", NULL, 0, CkIndex_Director::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */



/* DEFS: group ReadAssembler: IrrGroup{
ReadAssembler(const Session &session);
void shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data);
};
 */
#ifndef CK_TEMPLATES_ONLY
 int CkIndex_ReadAssembler::__idx=0;
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
/* DEFS: ReadAssembler(const Session &session);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data);
 */
void CProxyElement_ReadAssembler::shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data
  int impl_off=0;
  int impl_num_rdma_fields = 1;
  int impl_num_root_node = CkMyNode();
  ncpyBuffer_data.cnt=sizeof(char)*(num_bytes);
  ncpyBuffer_data.registerMem();
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
  }
  CMI_ZC_MSGTYPE((char *)UsrToEnv(impl_msg)) = CMK_ZC_P2P_RECV_MSG;
  if (ckIsDelegated()) {
    CkAbort("Entry methods with nocopy parameters not supported when called with delegation managers");
  } else {
    CkSendMsgBranch(CkIndex_ReadAssembler::idx_shareData_marshall2(), impl_msg, ckGetGroupPe(), ckGetGroupID(),0);
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: ReadAssembler(const Session &session);
 */
CkGroupID CProxy_ReadAssembler::ckNew(const Session &session, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const Session &session
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
  }
  UsrToEnv(impl_msg)->setMsgtype(BocInitMsg);
  CkGroupID gId = CkCreateGroup(CkIndex_ReadAssembler::__idx, CkIndex_ReadAssembler::idx_ReadAssembler_marshall1(), impl_msg);
  return gId;
}
  CProxy_ReadAssembler::CProxy_ReadAssembler(const Session &session, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const Session &session
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
  }
  UsrToEnv(impl_msg)->setMsgtype(BocInitMsg);
  ckSetGroupID(CkCreateGroup(CkIndex_ReadAssembler::__idx, CkIndex_ReadAssembler::idx_ReadAssembler_marshall1(), impl_msg));
}

// Entry point registration function
int CkIndex_ReadAssembler::reg_ReadAssembler_marshall1() {
  int epidx = CkRegisterEp("ReadAssembler(const Session &session)",
      reinterpret_cast<CkCallFnPtr>(_call_ReadAssembler_marshall1), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_ReadAssembler_marshall1);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_ReadAssembler_marshall1);

  return epidx;
}

void CkIndex_ReadAssembler::_call_ReadAssembler_marshall1(void* impl_msg, void* impl_obj_void)
{
  ReadAssembler* impl_obj = static_cast<ReadAssembler*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const Session &session*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<Session> session;
  implP|session;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  new (impl_obj_void) ReadAssembler(std::move(session.t));
}
int CkIndex_ReadAssembler::_callmarshall_ReadAssembler_marshall1(char* impl_buf, void* impl_obj_void) {
  ReadAssembler* impl_obj = static_cast<ReadAssembler*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const Session &session*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<Session> session;
  implP|session;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  new (impl_obj_void) ReadAssembler(std::move(session.t));
  return implP.size();
}
void CkIndex_ReadAssembler::_marshallmessagepup_ReadAssembler_marshall1(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const Session &session*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<Session> session;
  implP|session;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("session");
  implDestP|session;
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data);
 */
void CProxy_ReadAssembler::shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data
  int impl_off=0;
  int impl_num_rdma_fields = 1;
  int impl_num_root_node = CkMyNode();
  ncpyBuffer_data.cnt=sizeof(char)*(num_bytes);
  ncpyBuffer_data.registerMem();
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
  }
  CMI_ZC_MSGTYPE((char *)UsrToEnv(impl_msg)) = CMK_ZC_BCAST_RECV_MSG;
  if (ckIsDelegated()) {
     CkGroupMsgPrep(CkIndex_ReadAssembler::idx_shareData_marshall2(), impl_msg, ckGetGroupID());
     ckDelegatedTo()->GroupBroadcast(ckDelegatedPtr(),CkIndex_ReadAssembler::idx_shareData_marshall2(), impl_msg, ckGetGroupID());
  } else CkBroadcastMsgBranch(CkIndex_ReadAssembler::idx_shareData_marshall2(), impl_msg, ckGetGroupID(),0);
}
void CProxy_ReadAssembler::shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data, int npes, int *pes, const CkEntryOptions *impl_e_opts) {
  //Marshall: int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data
  int impl_off=0;
  int impl_num_rdma_fields = 1;
  int impl_num_root_node = CkMyNode();
  ncpyBuffer_data.cnt=sizeof(char)*(num_bytes);
  ncpyBuffer_data.registerMem();
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
  }
  CMI_ZC_MSGTYPE((char *)UsrToEnv(impl_msg)) = CMK_ZC_BCAST_RECV_MSG;
  CkSendMsgBranchMulti(CkIndex_ReadAssembler::idx_shareData_marshall2(), impl_msg, ckGetGroupID(), npes, pes,0);
}
void CProxy_ReadAssembler::shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data, CmiGroup &grp, const CkEntryOptions *impl_e_opts) {
  //Marshall: int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data
  int impl_off=0;
  int impl_num_rdma_fields = 1;
  int impl_num_root_node = CkMyNode();
  ncpyBuffer_data.cnt=sizeof(char)*(num_bytes);
  ncpyBuffer_data.registerMem();
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
  }
  CMI_ZC_MSGTYPE((char *)UsrToEnv(impl_msg)) = CMK_ZC_BCAST_RECV_MSG;
  CkSendMsgBranchGroup(CkIndex_ReadAssembler::idx_shareData_marshall2(), impl_msg, ckGetGroupID(), grp,0);
}

// Entry point registration function
int CkIndex_ReadAssembler::reg_shareData_marshall2() {
  int epidx = CkRegisterEp("shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data)",
      reinterpret_cast<CkCallFnPtr>(_call_shareData_marshall2), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_shareData_marshall2);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_shareData_marshall2);

  return epidx;
}

void CkIndex_ReadAssembler::_call_shareData_marshall2(void* impl_msg, void* impl_obj_void)
{
  ReadAssembler* impl_obj = static_cast<ReadAssembler*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data*/
  PUP::fromMem implP(impl_buf);
  char *impl_buf_begin = impl_buf;
  int impl_num_rdma_fields; implP|impl_num_rdma_fields;
  int impl_num_root_node; implP|impl_num_root_node;
  CkNcpyBuffer ncpyBuffer_data;
  implP|ncpyBuffer_data;
  char *ncpyBuffer_data_ptr = nullptr;
  CkNcpyBufferPost ncpyPost[1];
  int numPostAsync=0;
  initPostStruct(ncpyPost, 0 );
  PUP::detail::TemporaryObjectHolder<int> read_tag;
  implP|read_tag;
  PUP::detail::TemporaryObjectHolder<int> buffer_tag;
  implP|buffer_tag;
  PUP::detail::TemporaryObjectHolder<size_t> read_chare_offset;
  implP|read_chare_offset;
  PUP::detail::TemporaryObjectHolder<size_t> num_bytes;
  implP|num_bytes;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  CmiUInt8 myIndex = impl_obj->thisIndex;
  if(CMI_IS_ZC_RECV(env)) { // Message that executes Post EM on primary element
    CkRdmaAsyncPostPreprocess(env, impl_num_rdma_fields, ncpyPost);
    impl_obj->shareData(read_tag.t , buffer_tag.t , read_chare_offset.t , num_bytes.t , ncpyBuffer_data_ptr,ncpyPost);
    if(ncpyPost[0].postAsync) numPostAsync++;
    if(numPostAsync == 0) {
      void *buffPtrs[1];
      int buffSizes[1];
      if(ncpyBuffer_data_ptr == nullptr)
        CkAbort("Post Entry Method either doesn't call CkMatchBuffer or doesn't post the buffer by initializing the reference to the pointer for data");
      buffPtrs[0] = (void *)ncpyBuffer_data_ptr;
      buffSizes[0] = sizeof(char) * num_bytes.t;
      CkRdmaIssueRgets(env, buffPtrs, buffSizes, myIndex, ncpyPost);
    } else if(impl_num_rdma_fields -  numPostAsync > 0)
      CkAbort("Partial async posting of buffers is currently not supported!");
 } else if(CMI_ZC_MSGTYPE(env) == CMK_ZC_BCAST_RECV_DONE_MSG) {
    // Message that executes the Post EM on secondary elements
    NcpyEmInfo *ncpyEmInfo = (ncpyBuffer_data.ncpyEmInfo);
    NcpyBcastRecvPeerAckInfo *peerAckInfo = (ncpyBuffer_data.ncpyEmInfo->peerAckInfo);
    std::vector<int> *tagArray = ncpyBuffer_data.ncpyEmInfo->tagArray;
    if(isUnposted(tagArray, env, myIndex, impl_num_rdma_fields)) {
      CkRdmaAsyncPostPreprocess(env, 1, ncpyPost, myIndex, peerAckInfo);
      setPostStruct(ncpyPost, 0,ncpyBuffer_data,myIndex);
        impl_obj->shareData(read_tag.t , buffer_tag.t , read_chare_offset.t , num_bytes.t , ncpyBuffer_data_ptr,ncpyPost);
      if(ncpyPost[0].postAsync) numPostAsync++;
      if(ncpyPost[0].postAsync == false ) {
        if( ncpyBuffer_data.cnt <  sizeof(char) * num_bytes.t)
          CkAbort("Size of the posted buffer > Size of the source buffer ");
        if(ncpyBuffer_data_ptr == nullptr)
          CkAbort("Post Entry Method either doesn't call CkMatchBuffer or doesn't post the buffer by initializing the reference to the pointer for data");
        memcpy(ncpyBuffer_data_ptr,ncpyBuffer_data.ptr, sizeof(char) * num_bytes.t);
        ncpyPost[0].ncpyEmInfo->counter++;
        setPosted(tagArray, env, myIndex,  impl_num_rdma_fields,0);
      }
      if(numPostAsync == 0) {
        // Message that executes the Regular EM on secondary elements when all elements are posted inline
        impl_obj->shareData(std::move(read_tag.t), std::move(buffer_tag.t), std::move(read_chare_offset.t), std::move(num_bytes.t), ncpyBuffer_data_ptr);
        updatePeerCounter(ncpyEmInfo);
        CmiFree(ncpyPost[0].ncpyEmInfo);
      }
    } else { // Message that executes the Regular EM on secondary elements
      ncpyBuffer_data_ptr =  (char *)extractStoredBuffer(ncpyBuffer_data.ncpyEmInfo->tagArray, env, myIndex,impl_num_rdma_fields, 0);
      impl_obj->shareData(std::move(read_tag.t), std::move(buffer_tag.t), std::move(read_chare_offset.t), std::move(num_bytes.t), ncpyBuffer_data_ptr);
      updatePeerCounter(ncpyEmInfo);
    }
  } else {   // Final message that executes the Regular EM on primary element
      ncpyBuffer_data_ptr = (char *)ncpyBuffer_data.ptr;
  impl_obj->shareData(std::move(read_tag.t), std::move(buffer_tag.t), std::move(read_chare_offset.t), std::move(num_bytes.t), ncpyBuffer_data_ptr);
  }
}
int CkIndex_ReadAssembler::_callmarshall_shareData_marshall2(char* impl_buf, void* impl_obj_void) {
  ReadAssembler* impl_obj = static_cast<ReadAssembler*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data*/
  PUP::fromMem implP(impl_buf);
  char *impl_buf_begin = impl_buf;
  int impl_num_rdma_fields; implP|impl_num_rdma_fields;
  int impl_num_root_node; implP|impl_num_root_node;
  CkNcpyBuffer ncpyBuffer_data;
  implP|ncpyBuffer_data;
  char *ncpyBuffer_data_ptr = nullptr;
  CkNcpyBufferPost ncpyPost[1];
  int numPostAsync=0;
  initPostStruct(ncpyPost, 0 );
  PUP::detail::TemporaryObjectHolder<int> read_tag;
  implP|read_tag;
  PUP::detail::TemporaryObjectHolder<int> buffer_tag;
  implP|buffer_tag;
  PUP::detail::TemporaryObjectHolder<size_t> read_chare_offset;
  implP|read_chare_offset;
  PUP::detail::TemporaryObjectHolder<size_t> num_bytes;
  implP|num_bytes;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  CmiUInt8 myIndex = impl_obj->thisIndex;
  if(CMI_IS_ZC_RECV(env)) { // Message that executes Post EM on primary element
    CkRdmaAsyncPostPreprocess(env, impl_num_rdma_fields, ncpyPost);
    impl_obj->shareData(read_tag.t , buffer_tag.t , read_chare_offset.t , num_bytes.t , ncpyBuffer_data_ptr,ncpyPost);
    if(ncpyPost[0].postAsync) numPostAsync++;
    if(numPostAsync == 0) {
      void *buffPtrs[1];
      int buffSizes[1];
      if(ncpyBuffer_data_ptr == nullptr)
        CkAbort("Post Entry Method either doesn't call CkMatchBuffer or doesn't post the buffer by initializing the reference to the pointer for data");
      buffPtrs[0] = (void *)ncpyBuffer_data_ptr;
      buffSizes[0] = sizeof(char) * num_bytes.t;
      CkRdmaIssueRgets(env, buffPtrs, buffSizes, myIndex, ncpyPost);
    } else if(impl_num_rdma_fields -  numPostAsync > 0)
      CkAbort("Partial async posting of buffers is currently not supported!");
 } else if(CMI_ZC_MSGTYPE(env) == CMK_ZC_BCAST_RECV_DONE_MSG) {
    // Message that executes the Post EM on secondary elements
    NcpyEmInfo *ncpyEmInfo = (ncpyBuffer_data.ncpyEmInfo);
    NcpyBcastRecvPeerAckInfo *peerAckInfo = (ncpyBuffer_data.ncpyEmInfo->peerAckInfo);
    std::vector<int> *tagArray = ncpyBuffer_data.ncpyEmInfo->tagArray;
    if(isUnposted(tagArray, env, myIndex, impl_num_rdma_fields)) {
      CkRdmaAsyncPostPreprocess(env, 1, ncpyPost, myIndex, peerAckInfo);
      setPostStruct(ncpyPost, 0,ncpyBuffer_data,myIndex);
        impl_obj->shareData(read_tag.t , buffer_tag.t , read_chare_offset.t , num_bytes.t , ncpyBuffer_data_ptr,ncpyPost);
      if(ncpyPost[0].postAsync) numPostAsync++;
      if(ncpyPost[0].postAsync == false ) {
        if( ncpyBuffer_data.cnt <  sizeof(char) * num_bytes.t)
          CkAbort("Size of the posted buffer > Size of the source buffer ");
        if(ncpyBuffer_data_ptr == nullptr)
          CkAbort("Post Entry Method either doesn't call CkMatchBuffer or doesn't post the buffer by initializing the reference to the pointer for data");
        memcpy(ncpyBuffer_data_ptr,ncpyBuffer_data.ptr, sizeof(char) * num_bytes.t);
        ncpyPost[0].ncpyEmInfo->counter++;
        setPosted(tagArray, env, myIndex,  impl_num_rdma_fields,0);
      }
      if(numPostAsync == 0) {
        // Message that executes the Regular EM on secondary elements when all elements are posted inline
        impl_obj->shareData(std::move(read_tag.t), std::move(buffer_tag.t), std::move(read_chare_offset.t), std::move(num_bytes.t), ncpyBuffer_data_ptr);
        updatePeerCounter(ncpyEmInfo);
        CmiFree(ncpyPost[0].ncpyEmInfo);
      }
    } else { // Message that executes the Regular EM on secondary elements
      ncpyBuffer_data_ptr =  (char *)extractStoredBuffer(ncpyBuffer_data.ncpyEmInfo->tagArray, env, myIndex,impl_num_rdma_fields, 0);
      impl_obj->shareData(std::move(read_tag.t), std::move(buffer_tag.t), std::move(read_chare_offset.t), std::move(num_bytes.t), ncpyBuffer_data_ptr);
      updatePeerCounter(ncpyEmInfo);
    }
  } else {   // Final message that executes the Regular EM on primary element
      ncpyBuffer_data_ptr = (char *)ncpyBuffer_data.ptr;
  impl_obj->shareData(std::move(read_tag.t), std::move(buffer_tag.t), std::move(read_chare_offset.t), std::move(num_bytes.t), ncpyBuffer_data_ptr);
  }
  return implP.size();
}
void CkIndex_ReadAssembler::_marshallmessagepup_shareData_marshall2(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data*/
  PUP::fromMem implP(impl_buf);
  char *impl_buf_begin = impl_buf;
  int impl_num_rdma_fields; implP|impl_num_rdma_fields;
  int impl_num_root_node; implP|impl_num_root_node;
  CkNcpyBuffer ncpyBuffer_data;
  implP|ncpyBuffer_data;
  char *ncpyBuffer_data_ptr = nullptr;
  CkNcpyBufferPost ncpyPost[1];
  int numPostAsync=0;
  initPostStruct(ncpyPost, 0 );
  PUP::detail::TemporaryObjectHolder<int> read_tag;
  implP|read_tag;
  PUP::detail::TemporaryObjectHolder<int> buffer_tag;
  implP|buffer_tag;
  PUP::detail::TemporaryObjectHolder<size_t> read_chare_offset;
  implP|read_chare_offset;
  PUP::detail::TemporaryObjectHolder<size_t> num_bytes;
  implP|num_bytes;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("read_tag");
  implDestP|read_tag;
  if (implDestP.hasComments()) implDestP.comment("buffer_tag");
  implDestP|buffer_tag;
  if (implDestP.hasComments()) implDestP.comment("read_chare_offset");
  implDestP|read_chare_offset;
  if (implDestP.hasComments()) implDestP.comment("num_bytes");
  implDestP|num_bytes;
  if (implDestP.hasComments()) implDestP.comment("data");
  implDestP|ncpyBuffer_data;
}
PUPable_def(SINGLE_ARG(Closure_ReadAssembler::shareData_2_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: ReadAssembler(const Session &session);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data);
 */
void CProxySection_ReadAssembler::shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data
  int impl_off=0;
  int impl_num_rdma_fields = 1;
  int impl_num_root_node = CkMyNode();
  ncpyBuffer_data.cnt=sizeof(char)*(num_bytes);
  ncpyBuffer_data.registerMem();
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|impl_num_rdma_fields;
    implP|impl_num_root_node;
    implP|ncpyBuffer_data;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)read_chare_offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_bytes;
  }
  CMI_ZC_MSGTYPE((char *)UsrToEnv(impl_msg)) = CMK_ZC_BCAST_RECV_MSG;
  if (ckIsDelegated()) {
     ckDelegatedTo()->GroupSectionSend(ckDelegatedPtr(),CkIndex_ReadAssembler::idx_shareData_marshall2(), impl_msg, ckGetNumSections(), ckGetSectionIDs());
  } else {
    void *impl_msg_tmp;
    for (int i=0; i<ckGetNumSections(); ++i) {
       impl_msg_tmp= (i<ckGetNumSections()-1) ? CkCopyMsg((void **) &impl_msg):impl_msg;
       CkSendMsgBranchMulti(CkIndex_ReadAssembler::idx_shareData_marshall2(), impl_msg_tmp, ckGetGroupIDn(i), ckGetNumElements(i), ckGetElements(i),0);
    }
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void CkIndex_ReadAssembler::__register(const char *s, size_t size) {
  __idx = CkRegisterChare(s, size, TypeGroup);
  CkRegisterBase(__idx, CkIndex_IrrGroup::__idx);
   CkRegisterGroupIrr(__idx,ReadAssembler::isIrreducible());
  // REG: ReadAssembler(const Session &session);
  idx_ReadAssembler_marshall1();

  // REG: void shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data);
  idx_shareData_marshall2();

}
#endif /* CK_TEMPLATES_ONLY */

/* DEFS: group Manager: IrrGroup{
Manager();
void run();
void openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts);
void close(unsigned int opnum, const FileToken &token, const CkCallback &closed);
void addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready);
Manager(CkMigrateMessage* impl_msg);
};
 */
#ifndef CK_TEMPLATES_ONLY
 int CkIndex_Manager::__idx=0;
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
/* DEFS: Manager();
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void run();
 */
void CProxyElement_Manager::run(const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  if (ckIsDelegated()) {
     CkGroupMsgPrep(CkIndex_Manager::idx_run_void(), impl_msg, ckGetGroupID());
     ckDelegatedTo()->GroupSend(ckDelegatedPtr(),CkIndex_Manager::idx_run_void(), impl_msg, ckGetGroupPe(), ckGetGroupID());
  } else {
    CkSendMsgBranch(CkIndex_Manager::idx_run_void(), impl_msg, ckGetGroupPe(), ckGetGroupID(),0);
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts);
 */
void CProxyElement_Manager::openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
  }
  if (ckIsDelegated()) {
     CkGroupMsgPrep(CkIndex_Manager::idx_openFile_marshall3(), impl_msg, ckGetGroupID());
     ckDelegatedTo()->GroupSend(ckDelegatedPtr(),CkIndex_Manager::idx_openFile_marshall3(), impl_msg, ckGetGroupPe(), ckGetGroupID());
  } else {
    CkSendMsgBranch(CkIndex_Manager::idx_openFile_marshall3(), impl_msg, ckGetGroupPe(), ckGetGroupID(),0);
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void close(unsigned int opnum, const FileToken &token, const CkCallback &closed);
 */
void CProxyElement_Manager::close(unsigned int opnum, const FileToken &token, const CkCallback &closed, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: unsigned int opnum, const FileToken &token, const CkCallback &closed
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
  }
  if (ckIsDelegated()) {
     CkGroupMsgPrep(CkIndex_Manager::idx_close_marshall4(), impl_msg, ckGetGroupID());
     ckDelegatedTo()->GroupSend(ckDelegatedPtr(),CkIndex_Manager::idx_close_marshall4(), impl_msg, ckGetGroupPe(), ckGetGroupID());
  } else {
    CkSendMsgBranch(CkIndex_Manager::idx_close_marshall4(), impl_msg, ckGetGroupPe(), ckGetGroupID(),0);
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready);
 */
void CProxyElement_Manager::addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
  }
  if (ckIsDelegated()) {
     CkGroupMsgPrep(CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg, ckGetGroupID());
     ckDelegatedTo()->GroupSend(ckDelegatedPtr(),CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg, ckGetGroupPe(), ckGetGroupID());
  } else {
    CkSendMsgBranch(CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg, ckGetGroupPe(), ckGetGroupID(),0);
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: Manager(CkMigrateMessage* impl_msg);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: Manager();
 */
CkGroupID CProxy_Manager::ckNew(const CkEntryOptions *impl_e_opts)
{
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(BocInitMsg);
  CkGroupID gId = CkCreateGroup(CkIndex_Manager::__idx, CkIndex_Manager::idx_Manager_void(), impl_msg);
  return gId;
}

// Entry point registration function
int CkIndex_Manager::reg_Manager_void() {
  int epidx = CkRegisterEp("Manager()",
      reinterpret_cast<CkCallFnPtr>(_call_Manager_void), 0, __idx, 0);
  return epidx;
}

void CkIndex_Manager::_call_Manager_void(void* impl_msg, void* impl_obj_void)
{
  Manager* impl_obj = static_cast<Manager*>(impl_obj_void);
  new (impl_obj_void) Manager();
  if(UsrToEnv(impl_msg)->isVarSysMsg() == 0)
    CkFreeSysMsg(impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void run();
 */
void CProxy_Manager::run(const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  if (ckIsDelegated()) {
     CkGroupMsgPrep(CkIndex_Manager::idx_run_void(), impl_msg, ckGetGroupID());
     ckDelegatedTo()->GroupBroadcast(ckDelegatedPtr(),CkIndex_Manager::idx_run_void(), impl_msg, ckGetGroupID());
  } else CkBroadcastMsgBranch(CkIndex_Manager::idx_run_void(), impl_msg, ckGetGroupID(),0);
}
void CProxy_Manager::run(int npes, int *pes, const CkEntryOptions *impl_e_opts) {
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  CkSendMsgBranchMulti(CkIndex_Manager::idx_run_void(), impl_msg, ckGetGroupID(), npes, pes,0);
}
void CProxy_Manager::run(CmiGroup &grp, const CkEntryOptions *impl_e_opts) {
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  CkSendMsgBranchGroup(CkIndex_Manager::idx_run_void(), impl_msg, ckGetGroupID(), grp,0);
}

// Entry point registration function
int CkIndex_Manager::reg_run_void() {
  int epidx = CkRegisterEp("run()",
      reinterpret_cast<CkCallFnPtr>(_call_run_void), 0, __idx, 0);
  return epidx;
}

void CkIndex_Manager::_call_run_void(void* impl_msg, void* impl_obj_void)
{
  Manager* impl_obj = static_cast<Manager*>(impl_obj_void);
  impl_obj->_sdag_fnc_run();
  if(UsrToEnv(impl_msg)->isVarSysMsg() == 0)
    CkFreeSysMsg(impl_msg);
}
PUPable_def(SINGLE_ARG(Closure_Manager::run_2_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts);
 */
void CProxy_Manager::openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
  }
  if (ckIsDelegated()) {
     CkGroupMsgPrep(CkIndex_Manager::idx_openFile_marshall3(), impl_msg, ckGetGroupID());
     ckDelegatedTo()->GroupBroadcast(ckDelegatedPtr(),CkIndex_Manager::idx_openFile_marshall3(), impl_msg, ckGetGroupID());
  } else CkBroadcastMsgBranch(CkIndex_Manager::idx_openFile_marshall3(), impl_msg, ckGetGroupID(),0);
}
void CProxy_Manager::openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts, int npes, int *pes, const CkEntryOptions *impl_e_opts) {
  //Marshall: unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
  }
  CkSendMsgBranchMulti(CkIndex_Manager::idx_openFile_marshall3(), impl_msg, ckGetGroupID(), npes, pes,0);
}
void CProxy_Manager::openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts, CmiGroup &grp, const CkEntryOptions *impl_e_opts) {
  //Marshall: unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
  }
  CkSendMsgBranchGroup(CkIndex_Manager::idx_openFile_marshall3(), impl_msg, ckGetGroupID(), grp,0);
}

// Entry point registration function
int CkIndex_Manager::reg_openFile_marshall3() {
  int epidx = CkRegisterEp("openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts)",
      reinterpret_cast<CkCallFnPtr>(_call_openFile_marshall3), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_openFile_marshall3);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_openFile_marshall3);

  return epidx;
}

void CkIndex_Manager::_call_openFile_marshall3(void* impl_msg, void* impl_obj_void)
{
  Manager* impl_obj = static_cast<Manager*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  PUP::fromMem implP(impl_buf);
  Closure_Manager::openFile_3_closure* genClosure = new Closure_Manager::openFile_3_closure();
  implP|genClosure->opnum;
  implP|genClosure->token;
  implP|genClosure->name;
  implP|genClosure->opts;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->openFile(genClosure);
  genClosure->deref();
}
int CkIndex_Manager::_callmarshall_openFile_marshall3(char* impl_buf, void* impl_obj_void) {
  Manager* impl_obj = static_cast<Manager*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  PUP::fromMem implP(impl_buf);
  Closure_Manager::openFile_3_closure* genClosure = new Closure_Manager::openFile_3_closure();
  implP|genClosure->opnum;
  implP|genClosure->token;
  implP|genClosure->name;
  implP|genClosure->opts;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->openFile(genClosure);
  genClosure->deref();
  return implP.size();
}
void CkIndex_Manager::_marshallmessagepup_openFile_marshall3(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<unsigned int> opnum;
  implP|opnum;
  PUP::detail::TemporaryObjectHolder<FileToken> token;
  implP|token;
  PUP::detail::TemporaryObjectHolder<std::string> name;
  implP|name;
  PUP::detail::TemporaryObjectHolder<Options> opts;
  implP|opts;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("opnum");
  implDestP|opnum;
  if (implDestP.hasComments()) implDestP.comment("token");
  implDestP|token;
  if (implDestP.hasComments()) implDestP.comment("name");
  implDestP|name;
  if (implDestP.hasComments()) implDestP.comment("opts");
  implDestP|opts;
}
PUPable_def(SINGLE_ARG(Closure_Manager::openFile_3_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void close(unsigned int opnum, const FileToken &token, const CkCallback &closed);
 */
void CProxy_Manager::close(unsigned int opnum, const FileToken &token, const CkCallback &closed, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: unsigned int opnum, const FileToken &token, const CkCallback &closed
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
  }
  if (ckIsDelegated()) {
     CkGroupMsgPrep(CkIndex_Manager::idx_close_marshall4(), impl_msg, ckGetGroupID());
     ckDelegatedTo()->GroupBroadcast(ckDelegatedPtr(),CkIndex_Manager::idx_close_marshall4(), impl_msg, ckGetGroupID());
  } else CkBroadcastMsgBranch(CkIndex_Manager::idx_close_marshall4(), impl_msg, ckGetGroupID(),0);
}
void CProxy_Manager::close(unsigned int opnum, const FileToken &token, const CkCallback &closed, int npes, int *pes, const CkEntryOptions *impl_e_opts) {
  //Marshall: unsigned int opnum, const FileToken &token, const CkCallback &closed
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
  }
  CkSendMsgBranchMulti(CkIndex_Manager::idx_close_marshall4(), impl_msg, ckGetGroupID(), npes, pes,0);
}
void CProxy_Manager::close(unsigned int opnum, const FileToken &token, const CkCallback &closed, CmiGroup &grp, const CkEntryOptions *impl_e_opts) {
  //Marshall: unsigned int opnum, const FileToken &token, const CkCallback &closed
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
  }
  CkSendMsgBranchGroup(CkIndex_Manager::idx_close_marshall4(), impl_msg, ckGetGroupID(), grp,0);
}

// Entry point registration function
int CkIndex_Manager::reg_close_marshall4() {
  int epidx = CkRegisterEp("close(unsigned int opnum, const FileToken &token, const CkCallback &closed)",
      reinterpret_cast<CkCallFnPtr>(_call_close_marshall4), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_close_marshall4);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_close_marshall4);

  return epidx;
}

void CkIndex_Manager::_call_close_marshall4(void* impl_msg, void* impl_obj_void)
{
  Manager* impl_obj = static_cast<Manager*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  PUP::fromMem implP(impl_buf);
  Closure_Manager::close_4_closure* genClosure = new Closure_Manager::close_4_closure();
  implP|genClosure->opnum;
  implP|genClosure->token;
  implP|genClosure->closed;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->close(genClosure);
  genClosure->deref();
}
int CkIndex_Manager::_callmarshall_close_marshall4(char* impl_buf, void* impl_obj_void) {
  Manager* impl_obj = static_cast<Manager*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  PUP::fromMem implP(impl_buf);
  Closure_Manager::close_4_closure* genClosure = new Closure_Manager::close_4_closure();
  implP|genClosure->opnum;
  implP|genClosure->token;
  implP|genClosure->closed;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->close(genClosure);
  genClosure->deref();
  return implP.size();
}
void CkIndex_Manager::_marshallmessagepup_close_marshall4(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: unsigned int opnum, const FileToken &token, const CkCallback &closed*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<unsigned int> opnum;
  implP|opnum;
  PUP::detail::TemporaryObjectHolder<FileToken> token;
  implP|token;
  PUP::detail::TemporaryObjectHolder<CkCallback> closed;
  implP|closed;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("opnum");
  implDestP|opnum;
  if (implDestP.hasComments()) implDestP.comment("token");
  implDestP|token;
  if (implDestP.hasComments()) implDestP.comment("closed");
  implDestP|closed;
}
PUPable_def(SINGLE_ARG(Closure_Manager::close_4_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready);
 */
void CProxy_Manager::addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
  }
  if (ckIsDelegated()) {
     CkGroupMsgPrep(CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg, ckGetGroupID());
     ckDelegatedTo()->GroupBroadcast(ckDelegatedPtr(),CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg, ckGetGroupID());
  } else CkBroadcastMsgBranch(CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg, ckGetGroupID(),0);
}
void CProxy_Manager::addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready, int npes, int *pes, const CkEntryOptions *impl_e_opts) {
  //Marshall: const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
  }
  CkSendMsgBranchMulti(CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg, ckGetGroupID(), npes, pes,0);
}
void CProxy_Manager::addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready, CmiGroup &grp, const CkEntryOptions *impl_e_opts) {
  //Marshall: const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
  }
  CkSendMsgBranchGroup(CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg, ckGetGroupID(), grp,0);
}

// Entry point registration function
int CkIndex_Manager::reg_addSessionReadAssemblerMapping_marshall5() {
  int epidx = CkRegisterEp("addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready)",
      reinterpret_cast<CkCallFnPtr>(_call_addSessionReadAssemblerMapping_marshall5), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_addSessionReadAssemblerMapping_marshall5);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_addSessionReadAssemblerMapping_marshall5);

  return epidx;
}

void CkIndex_Manager::_call_addSessionReadAssemblerMapping_marshall5(void* impl_msg, void* impl_obj_void)
{
  Manager* impl_obj = static_cast<Manager*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<Session> session;
  implP|session;
  PUP::detail::TemporaryObjectHolder<CProxy_ReadAssembler> ra;
  implP|ra;
  PUP::detail::TemporaryObjectHolder<CkCallback> ready;
  implP|ready;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->addSessionReadAssemblerMapping(std::move(session.t), std::move(ra.t), std::move(ready.t));
}
int CkIndex_Manager::_callmarshall_addSessionReadAssemblerMapping_marshall5(char* impl_buf, void* impl_obj_void) {
  Manager* impl_obj = static_cast<Manager*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<Session> session;
  implP|session;
  PUP::detail::TemporaryObjectHolder<CProxy_ReadAssembler> ra;
  implP|ra;
  PUP::detail::TemporaryObjectHolder<CkCallback> ready;
  implP|ready;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->addSessionReadAssemblerMapping(std::move(session.t), std::move(ra.t), std::move(ready.t));
  return implP.size();
}
void CkIndex_Manager::_marshallmessagepup_addSessionReadAssemblerMapping_marshall5(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<Session> session;
  implP|session;
  PUP::detail::TemporaryObjectHolder<CProxy_ReadAssembler> ra;
  implP|ra;
  PUP::detail::TemporaryObjectHolder<CkCallback> ready;
  implP|ready;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("session");
  implDestP|session;
  if (implDestP.hasComments()) implDestP.comment("ra");
  implDestP|ra;
  if (implDestP.hasComments()) implDestP.comment("ready");
  implDestP|ready;
}
PUPable_def(SINGLE_ARG(Closure_Manager::addSessionReadAssemblerMapping_5_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: Manager(CkMigrateMessage* impl_msg);
 */

// Entry point registration function
int CkIndex_Manager::reg_Manager_CkMigrateMessage() {
  int epidx = CkRegisterEp("Manager(CkMigrateMessage* impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_Manager_CkMigrateMessage), 0, __idx, 0);
  return epidx;
}

void CkIndex_Manager::_call_Manager_CkMigrateMessage(void* impl_msg, void* impl_obj_void)
{
  new (impl_obj_void) Manager((CkMigrateMessage*)impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: Manager();
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void run();
 */
void CProxySection_Manager::run(const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  if (ckIsDelegated()) {
     ckDelegatedTo()->GroupSectionSend(ckDelegatedPtr(),CkIndex_Manager::idx_run_void(), impl_msg, ckGetNumSections(), ckGetSectionIDs());
  } else {
    void *impl_msg_tmp;
    for (int i=0; i<ckGetNumSections(); ++i) {
       impl_msg_tmp= (i<ckGetNumSections()-1) ? CkCopyMsg((void **) &impl_msg):impl_msg;
       CkSendMsgBranchMulti(CkIndex_Manager::idx_run_void(), impl_msg_tmp, ckGetGroupIDn(i), ckGetNumElements(i), ckGetElements(i),0);
    }
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts);
 */
void CProxySection_Manager::openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::string>::type>::type &)name;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Options>::type>::type &)opts;
  }
  if (ckIsDelegated()) {
     ckDelegatedTo()->GroupSectionSend(ckDelegatedPtr(),CkIndex_Manager::idx_openFile_marshall3(), impl_msg, ckGetNumSections(), ckGetSectionIDs());
  } else {
    void *impl_msg_tmp;
    for (int i=0; i<ckGetNumSections(); ++i) {
       impl_msg_tmp= (i<ckGetNumSections()-1) ? CkCopyMsg((void **) &impl_msg):impl_msg;
       CkSendMsgBranchMulti(CkIndex_Manager::idx_openFile_marshall3(), impl_msg_tmp, ckGetGroupIDn(i), ckGetNumElements(i), ckGetElements(i),0);
    }
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void close(unsigned int opnum, const FileToken &token, const CkCallback &closed);
 */
void CProxySection_Manager::close(unsigned int opnum, const FileToken &token, const CkCallback &closed, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: unsigned int opnum, const FileToken &token, const CkCallback &closed
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|opnum;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)token;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)closed;
  }
  if (ckIsDelegated()) {
     ckDelegatedTo()->GroupSectionSend(ckDelegatedPtr(),CkIndex_Manager::idx_close_marshall4(), impl_msg, ckGetNumSections(), ckGetSectionIDs());
  } else {
    void *impl_msg_tmp;
    for (int i=0; i<ckGetNumSections(); ++i) {
       impl_msg_tmp= (i<ckGetNumSections()-1) ? CkCopyMsg((void **) &impl_msg):impl_msg;
       CkSendMsgBranchMulti(CkIndex_Manager::idx_close_marshall4(), impl_msg_tmp, ckGetGroupIDn(i), ckGetNumElements(i), ckGetElements(i),0);
    }
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready);
 */
void CProxySection_Manager::addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready, const CkEntryOptions *impl_e_opts)
{
  ckCheck();
  //Marshall: const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<Session>::type>::type &)session;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CkCallback>::type>::type &)ready;
  }
  if (ckIsDelegated()) {
     ckDelegatedTo()->GroupSectionSend(ckDelegatedPtr(),CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg, ckGetNumSections(), ckGetSectionIDs());
  } else {
    void *impl_msg_tmp;
    for (int i=0; i<ckGetNumSections(); ++i) {
       impl_msg_tmp= (i<ckGetNumSections()-1) ? CkCopyMsg((void **) &impl_msg):impl_msg;
       CkSendMsgBranchMulti(CkIndex_Manager::idx_addSessionReadAssemblerMapping_marshall5(), impl_msg_tmp, ckGetGroupIDn(i), ckGetNumElements(i), ckGetElements(i),0);
    }
  }
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: Manager(CkMigrateMessage* impl_msg);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void CkIndex_Manager::__register(const char *s, size_t size) {
  __idx = CkRegisterChare(s, size, TypeGroup);
  CkRegisterBase(__idx, CkIndex_IrrGroup::__idx);
   CkRegisterGroupIrr(__idx,Manager::isIrreducible());
  // REG: Manager();
  idx_Manager_void();
  CkRegisterDefaultCtor(__idx, idx_Manager_void());

  // REG: void run();
  idx_run_void();

  // REG: void openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts);
  idx_openFile_marshall3();

  // REG: void close(unsigned int opnum, const FileToken &token, const CkCallback &closed);
  idx_close_marshall4();

  // REG: void addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready);
  idx_addSessionReadAssemblerMapping_marshall5();

  // REG: Manager(CkMigrateMessage* impl_msg);
  idx_Manager_CkMigrateMessage();
  CkRegisterMigCtor(__idx, idx_Manager_CkMigrateMessage());

  Manager::__sdag_register(); // Potentially missing Manager_SDAG_CODE in your class definition?
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
void Manager::run(){
  CkPrintf("Error> Direct call to SDAG entry method \'%s::%s\'!\n", "Manager", "run()"); 
  CkAbort("Direct SDAG call is not allowed for SDAG entry methods having when constructs. Call such SDAG methods using a proxy"); 
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Manager::_sdag_fnc_run() {
  _TRACE_END_EXECUTE(); 
  if (!__dep.get()) _sdag_init();
  _slist_0();
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::run_end() {
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_slist_0() {
  _while_0();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_slist_0_end() {
  run_end();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_while_0() {
  if (true) {
    _slist_1();
  } else {
    _slist_0_end();
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_while_0_end() {
  if (true) {
    _slist_1();
  } else {
    _slist_0_end();
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_slist_1() {
  _case_0();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_slist_1_end() {
  _while_0_end();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_case_0() {
  _caselist_0();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_case_0_end() {
  _serial_2();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_caselist_0() {
  SDAG::CSpeculator* _cs0 = new SDAG::CSpeculator(__dep->getAndIncrementSpeculationIndex());
  SDAG::Continuation* c = 0;
  c = _when_0(_cs0);
  if (!c) return;
  else c->speculationIndex = _cs0->speculationIndex;
  c = _when_1(_cs0);
  if (!c) return;
  else c->speculationIndex = _cs0->speculationIndex;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_caselist_0_end(SDAG::CSpeculator* _cs0) {
  _cs0->deref();
  _case_0_end();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Manager::_when_0(SDAG::CSpeculator* _cs0) {
  CMK_REFNUM_TYPE refnum_0;
  {
    {
      refnum_0 = opnum;
    }
  }
  return _when_0(_cs0, refnum_0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Manager::_when_0(SDAG::CSpeculator* _cs0, int refnum_0) {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(0, true, refnum_0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    __dep->removeAllSpeculationIndex(_cs0->speculationIndex);
    _serial_0(_cs0, static_cast<Closure_Manager::openFile_3_closure*>(buf0->cl));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(0);
    c->addClosure(_cs0);
    c->entries.push_back(0);
    c->refnums.push_back(refnum_0);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_when_0_end(SDAG::CSpeculator* _cs0, Closure_Manager::openFile_3_closure* gen1) {
  _caselist_0_end(_cs0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_serial_0(SDAG::CSpeculator* _cs0, Closure_Manager::openFile_3_closure* gen1) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Manager_serial_0()), CkMyPe(), 0, NULL, this); 
  {
    {
      unsigned int& opnum_ = gen1->getP0();
      FileToken& token = gen1->getP1();
      std::string& name = gen1->getP2();
      Options& opts = gen1->getP3();
      { // begin serial block
#line 124 "ckio.ci"
 prepareFile(token, name, opts); 
#line 4755 "CkIO_impl.def.h"
      } // end serial block
    }
  }
  _TRACE_END_EXECUTE(); 
  _when_0_end(_cs0, gen1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Manager::_when_1(SDAG::CSpeculator* _cs0) {
  CMK_REFNUM_TYPE refnum_0;
  {
    {
      refnum_0 = opnum;
    }
  }
  return _when_1(_cs0, refnum_0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* Manager::_when_1(SDAG::CSpeculator* _cs0, int refnum_0) {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(1, true, refnum_0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    __dep->removeAllSpeculationIndex(_cs0->speculationIndex);
    _serial_1(_cs0, static_cast<Closure_Manager::close_4_closure*>(buf0->cl));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(1);
    c->addClosure(_cs0);
    c->entries.push_back(1);
    c->refnums.push_back(refnum_0);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_when_1_end(SDAG::CSpeculator* _cs0, Closure_Manager::close_4_closure* gen1) {
  _caselist_0_end(_cs0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_serial_1(SDAG::CSpeculator* _cs0, Closure_Manager::close_4_closure* gen1) {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Manager_serial_1()), CkMyPe(), 0, NULL, this); 
  {
    {
      unsigned int& opnum_ = gen1->getP0();
      FileToken& token = gen1->getP1();
      CkCallback& closed = gen1->getP2();
      { // begin serial block
#line 126 "ckio.ci"
 doClose(token, closed); 
#line 4817 "CkIO_impl.def.h"
      } // end serial block
    }
  }
  _TRACE_END_EXECUTE(); 
  _when_1_end(_cs0, gen1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_serial_2() {
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_Manager_serial_2()), CkMyPe(), 0, NULL, this); 
  { // begin serial block
#line 128 "ckio.ci"
 opnum++; 
#line 4833 "CkIO_impl.def.h"
  } // end serial block
  _TRACE_END_EXECUTE(); 
  _slist_1_end();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::openFile(unsigned int opnum_, FileToken token, std::string name, Options opts){
  Closure_Manager::openFile_3_closure* genClosure = new Closure_Manager::openFile_3_closure();
  genClosure->getP0() = opnum_;
  genClosure->getP1() = token;
  genClosure->getP2() = name;
  genClosure->getP3() = opts;
  openFile(genClosure);
  genClosure->deref();
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Manager::openFile(Closure_Manager::openFile_3_closure* genClosure){
  if (!__dep.get()) _sdag_init();
  if (!genClosure->hasRefnum) genClosure->setRefnum(genClosure->getP0());
  __dep->pushBuffer(0, genClosure);
  SDAG::Continuation* c = __dep->tryFindContinuation(0);
  if (c) {
    _TRACE_END_EXECUTE(); 
    _when_0(
      static_cast<SDAG::CSpeculator*>(c->closure[0]), 
      c->refnums[0]
    );
    _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
    delete c;
  }
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Manager::close(unsigned int opnum_, FileToken token, CkCallback closed){
  Closure_Manager::close_4_closure* genClosure = new Closure_Manager::close_4_closure();
  genClosure->getP0() = opnum_;
  genClosure->getP1() = token;
  genClosure->getP2() = closed;
  close(genClosure);
  genClosure->deref();
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Manager::close(Closure_Manager::close_4_closure* genClosure){
  if (!__dep.get()) _sdag_init();
  if (!genClosure->hasRefnum) genClosure->setRefnum(genClosure->getP0());
  __dep->pushBuffer(1, genClosure);
  SDAG::Continuation* c = __dep->tryFindContinuation(1);
  if (c) {
    _TRACE_END_EXECUTE(); 
    _when_1(
      static_cast<SDAG::CSpeculator*>(c->closure[0]), 
      c->refnums[0]
    );
    _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, NULL, this); 
    delete c;
  }
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Manager::_sdag_init() { // Potentially missing Manager_SDAG_CODE in your class definition?
  __dep.reset(new SDAG::Dependency(2,2));
  __dep->addDepends(0,0);
  __dep->addDepends(1,1);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::__sdag_init() { // Potentially missing Manager_SDAG_CODE in your class definition?
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void Manager::_sdag_pup(PUP::er &p) {  // Potentially missing Manager_SDAG_CODE in your class definition?
  p|__dep;
}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void Manager::__sdag_register() { // Potentially missing Manager_SDAG_CODE in your class definition?
  (void)_sdag_idx_Manager_serial_0();
  (void)_sdag_idx_Manager_serial_1();
  (void)_sdag_idx_Manager_serial_2();
  PUPable_reg(SINGLE_ARG(Closure_Manager::run_2_closure));
  PUPable_reg(SINGLE_ARG(Closure_Manager::openFile_3_closure));
  PUPable_reg(SINGLE_ARG(Closure_Manager::close_4_closure));
  PUPable_reg(SINGLE_ARG(Closure_Manager::addSessionReadAssemblerMapping_5_closure));
  PUPable_reg(SINGLE_ARG(Closure_Manager::run_2_closure));
  PUPable_reg(SINGLE_ARG(Closure_Manager::openFile_3_closure));
  PUPable_reg(SINGLE_ARG(Closure_Manager::close_4_closure));
  PUPable_reg(SINGLE_ARG(Closure_Manager::addSessionReadAssemblerMapping_5_closure));
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Manager::_sdag_idx_Manager_serial_0() { // Potentially missing Manager_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Manager_serial_0();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Manager::_sdag_reg_Manager_serial_0() { // Potentially missing Manager_SDAG_CODE in your class definition?
  return CkRegisterEp("Manager_serial_0", NULL, 0, CkIndex_Manager::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Manager::_sdag_idx_Manager_serial_1() { // Potentially missing Manager_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Manager_serial_1();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Manager::_sdag_reg_Manager_serial_1() { // Potentially missing Manager_SDAG_CODE in your class definition?
  return CkRegisterEp("Manager_serial_1", NULL, 0, CkIndex_Manager::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Manager::_sdag_idx_Manager_serial_2() { // Potentially missing Manager_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_Manager_serial_2();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int Manager::_sdag_reg_Manager_serial_2() { // Potentially missing Manager_SDAG_CODE in your class definition?
  return CkRegisterEp("Manager_serial_2", NULL, 0, CkIndex_Manager::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */



/* DEFS: array WriteSession: ArrayElement{
WriteSession(const FileToken &file, const size_t &offset, const size_t &bytes);
void forwardData(const char *data, const size_t &bytes, const size_t &offset);
void syncData();
WriteSession(CkMigrateMessage* impl_msg);
};
 */
#ifndef CK_TEMPLATES_ONLY
 int CkIndex_WriteSession::__idx=0;
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void CProxySection_WriteSession::contribute(CkSectionInfo &sid, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(sid, userData, fragSize);
}

void CProxySection_WriteSession::contribute(int dataSize,void *data,CkReduction::reducerType type, CkSectionInfo &sid, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(dataSize, data, type, sid, userData, fragSize);
}

template <typename T>
void CProxySection_WriteSession::contribute(std::vector<T> &data, CkReduction::reducerType type, CkSectionInfo &sid, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(data, type, sid, userData, fragSize);
}

void CProxySection_WriteSession::contribute(CkSectionInfo &sid, const CkCallback &cb, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(sid, cb, userData, fragSize);
}

void CProxySection_WriteSession::contribute(int dataSize,void *data,CkReduction::reducerType type, CkSectionInfo &sid, const CkCallback &cb, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(dataSize, data, type, sid, cb, userData, fragSize);
}

template <typename T>
void CProxySection_WriteSession::contribute(std::vector<T> &data, CkReduction::reducerType type, CkSectionInfo &sid, const CkCallback &cb, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(data, type, sid, cb, userData, fragSize);
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
/* DEFS: WriteSession(const FileToken &file, const size_t &offset, const size_t &bytes);
 */
void CProxyElement_WriteSession::insert(const FileToken &file, const size_t &offset, const size_t &bytes, int onPE, const CkEntryOptions *impl_e_opts)
{ 
   //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
  }
   UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
   ckInsert((CkArrayMessage *)impl_msg,CkIndex_WriteSession::idx_WriteSession_marshall1(),onPE);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void forwardData(const char *data, const size_t &bytes, const size_t &offset);
 */
void CProxyElement_WriteSession::forwardData(const char *data, const size_t &bytes, const size_t &offset, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: const char *data, const size_t &bytes, const size_t &offset
  int impl_off=0;
  int impl_arrstart=0;
  int impl_off_data, impl_cnt_data;
  impl_off_data=impl_off=CK_ALIGN(impl_off,sizeof(char));
  impl_off+=(impl_cnt_data=sizeof(char)*(bytes));
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|impl_off_data;
    implP|impl_cnt_data;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    impl_arrstart=CK_ALIGN(implP.size(),16);
    impl_off+=impl_arrstart;
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|impl_off_data;
    implP|impl_cnt_data;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
  }
  char *impl_buf=impl_msg->msgBuf+impl_arrstart;
  memcpy(impl_buf+impl_off_data,data,impl_cnt_data);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_WriteSession::idx_forwardData_marshall2(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void syncData();
 */
void CProxyElement_WriteSession::syncData(const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_WriteSession::idx_syncData_void(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: WriteSession(CkMigrateMessage* impl_msg);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: WriteSession(const FileToken &file, const size_t &offset, const size_t &bytes);
 */
CkArrayID CProxy_WriteSession::ckNew(const FileToken &file, const size_t &offset, const size_t &bytes, const CkArrayOptions &opts, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
  }
  UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
  CkArrayID gId = ckCreateArray((CkArrayMessage *)impl_msg, CkIndex_WriteSession::idx_WriteSession_marshall1(), opts);
  return gId;
}
void CProxy_WriteSession::ckNew(const FileToken &file, const size_t &offset, const size_t &bytes, const CkArrayOptions &opts, CkCallback _ck_array_creation_cb, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
  }
  UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
  CkSendAsyncCreateArray(CkIndex_WriteSession::idx_WriteSession_marshall1(), _ck_array_creation_cb, opts, impl_msg);
}
CkArrayID CProxy_WriteSession::ckNew(const FileToken &file, const size_t &offset, const size_t &bytes, const int s1, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
  }
  CkArrayOptions opts(s1);
  UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
  CkArrayID gId = ckCreateArray((CkArrayMessage *)impl_msg, CkIndex_WriteSession::idx_WriteSession_marshall1(), opts);
  return gId;
}
void CProxy_WriteSession::ckNew(const FileToken &file, const size_t &offset, const size_t &bytes, const int s1, CkCallback _ck_array_creation_cb, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
  }
  CkArrayOptions opts(s1);
  UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
  CkSendAsyncCreateArray(CkIndex_WriteSession::idx_WriteSession_marshall1(), _ck_array_creation_cb, opts, impl_msg);
}

// Entry point registration function
int CkIndex_WriteSession::reg_WriteSession_marshall1() {
  int epidx = CkRegisterEp("WriteSession(const FileToken &file, const size_t &offset, const size_t &bytes)",
      reinterpret_cast<CkCallFnPtr>(_call_WriteSession_marshall1), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_WriteSession_marshall1);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_WriteSession_marshall1);

  return epidx;
}

void CkIndex_WriteSession::_call_WriteSession_marshall1(void* impl_msg, void* impl_obj_void)
{
  WriteSession* impl_obj = static_cast<WriteSession*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &offset, const size_t &bytes*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  new (impl_obj_void) WriteSession(std::move(file.t), std::move(offset.t), std::move(bytes.t));
}
int CkIndex_WriteSession::_callmarshall_WriteSession_marshall1(char* impl_buf, void* impl_obj_void) {
  WriteSession* impl_obj = static_cast<WriteSession*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &offset, const size_t &bytes*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  new (impl_obj_void) WriteSession(std::move(file.t), std::move(offset.t), std::move(bytes.t));
  return implP.size();
}
void CkIndex_WriteSession::_marshallmessagepup_WriteSession_marshall1(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &offset, const size_t &bytes*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("file");
  implDestP|file;
  if (implDestP.hasComments()) implDestP.comment("offset");
  implDestP|offset;
  if (implDestP.hasComments()) implDestP.comment("bytes");
  implDestP|bytes;
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void forwardData(const char *data, const size_t &bytes, const size_t &offset);
 */
void CProxy_WriteSession::forwardData(const char *data, const size_t &bytes, const size_t &offset, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: const char *data, const size_t &bytes, const size_t &offset
  int impl_off=0;
  int impl_arrstart=0;
  int impl_off_data, impl_cnt_data;
  impl_off_data=impl_off=CK_ALIGN(impl_off,sizeof(char));
  impl_off+=(impl_cnt_data=sizeof(char)*(bytes));
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|impl_off_data;
    implP|impl_cnt_data;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    impl_arrstart=CK_ALIGN(implP.size(),16);
    impl_off+=impl_arrstart;
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|impl_off_data;
    implP|impl_cnt_data;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
  }
  char *impl_buf=impl_msg->msgBuf+impl_arrstart;
  memcpy(impl_buf+impl_off_data,data,impl_cnt_data);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckBroadcast(impl_amsg, CkIndex_WriteSession::idx_forwardData_marshall2(),0);
}

// Entry point registration function
int CkIndex_WriteSession::reg_forwardData_marshall2() {
  int epidx = CkRegisterEp("forwardData(const char *data, const size_t &bytes, const size_t &offset)",
      reinterpret_cast<CkCallFnPtr>(_call_forwardData_marshall2), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_forwardData_marshall2);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_forwardData_marshall2);

  return epidx;
}

void CkIndex_WriteSession::_call_forwardData_marshall2(void* impl_msg, void* impl_obj_void)
{
  WriteSession* impl_obj = static_cast<WriteSession*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const char *data, const size_t &bytes, const size_t &offset*/
  PUP::fromMem implP(impl_buf);
  int impl_off_data, impl_cnt_data;
  implP|impl_off_data;
  implP|impl_cnt_data;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  char *data=(char *)(impl_buf+impl_off_data);
  impl_obj->forwardData(data, std::move(bytes.t), std::move(offset.t));
}
int CkIndex_WriteSession::_callmarshall_forwardData_marshall2(char* impl_buf, void* impl_obj_void) {
  WriteSession* impl_obj = static_cast<WriteSession*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const char *data, const size_t &bytes, const size_t &offset*/
  PUP::fromMem implP(impl_buf);
  int impl_off_data, impl_cnt_data;
  implP|impl_off_data;
  implP|impl_cnt_data;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  char *data=(char *)(impl_buf+impl_off_data);
  impl_obj->forwardData(data, std::move(bytes.t), std::move(offset.t));
  return implP.size();
}
void CkIndex_WriteSession::_marshallmessagepup_forwardData_marshall2(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const char *data, const size_t &bytes, const size_t &offset*/
  PUP::fromMem implP(impl_buf);
  int impl_off_data, impl_cnt_data;
  implP|impl_off_data;
  implP|impl_cnt_data;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  char *data=(char *)(impl_buf+impl_off_data);
  if (implDestP.hasComments()) implDestP.comment("data");
  implDestP.synchronize(PUP::sync_begin_array);
  for (int impl_i=0;impl_i*(sizeof(*data))<impl_cnt_data;impl_i++) {
    implDestP.synchronize(PUP::sync_item);
    implDestP|data[impl_i];
  }
  implDestP.synchronize(PUP::sync_end_array);
  if (implDestP.hasComments()) implDestP.comment("bytes");
  implDestP|bytes;
  if (implDestP.hasComments()) implDestP.comment("offset");
  implDestP|offset;
}
PUPable_def(SINGLE_ARG(Closure_WriteSession::forwardData_2_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void syncData();
 */
void CProxy_WriteSession::syncData(const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckBroadcast(impl_amsg, CkIndex_WriteSession::idx_syncData_void(),0);
}

// Entry point registration function
int CkIndex_WriteSession::reg_syncData_void() {
  int epidx = CkRegisterEp("syncData()",
      reinterpret_cast<CkCallFnPtr>(_call_syncData_void), 0, __idx, 0);
  return epidx;
}

void CkIndex_WriteSession::_call_syncData_void(void* impl_msg, void* impl_obj_void)
{
  WriteSession* impl_obj = static_cast<WriteSession*>(impl_obj_void);
  impl_obj->syncData();
  if(UsrToEnv(impl_msg)->isVarSysMsg() == 0)
    CkFreeSysMsg(impl_msg);
}
PUPable_def(SINGLE_ARG(Closure_WriteSession::syncData_3_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: WriteSession(CkMigrateMessage* impl_msg);
 */

// Entry point registration function
int CkIndex_WriteSession::reg_WriteSession_CkMigrateMessage() {
  int epidx = CkRegisterEp("WriteSession(CkMigrateMessage* impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_WriteSession_CkMigrateMessage), 0, __idx, 0);
  return epidx;
}

void CkIndex_WriteSession::_call_WriteSession_CkMigrateMessage(void* impl_msg, void* impl_obj_void)
{
  call_migration_constructor<WriteSession> c = impl_obj_void;
  c((CkMigrateMessage*)impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: WriteSession(const FileToken &file, const size_t &offset, const size_t &bytes);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void forwardData(const char *data, const size_t &bytes, const size_t &offset);
 */
void CProxySection_WriteSession::forwardData(const char *data, const size_t &bytes, const size_t &offset, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: const char *data, const size_t &bytes, const size_t &offset
  int impl_off=0;
  int impl_arrstart=0;
  int impl_off_data, impl_cnt_data;
  impl_off_data=impl_off=CK_ALIGN(impl_off,sizeof(char));
  impl_off+=(impl_cnt_data=sizeof(char)*(bytes));
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|impl_off_data;
    implP|impl_cnt_data;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    impl_arrstart=CK_ALIGN(implP.size(),16);
    impl_off+=impl_arrstart;
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|impl_off_data;
    implP|impl_cnt_data;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
  }
  char *impl_buf=impl_msg->msgBuf+impl_arrstart;
  memcpy(impl_buf+impl_off_data,data,impl_cnt_data);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_WriteSession::idx_forwardData_marshall2(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void syncData();
 */
void CProxySection_WriteSession::syncData(const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_WriteSession::idx_syncData_void(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: WriteSession(CkMigrateMessage* impl_msg);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void CkIndex_WriteSession::__register(const char *s, size_t size) {
  __idx = CkRegisterChare(s, size, TypeArray);
  CkRegisterArrayDimensions(__idx, 1);
  CkRegisterBase(__idx, CkIndex_ArrayElement::__idx);
  // REG: WriteSession(const FileToken &file, const size_t &offset, const size_t &bytes);
  idx_WriteSession_marshall1();

  // REG: void forwardData(const char *data, const size_t &bytes, const size_t &offset);
  idx_forwardData_marshall2();

  // REG: void syncData();
  idx_syncData_void();

  // REG: WriteSession(CkMigrateMessage* impl_msg);
  idx_WriteSession_CkMigrateMessage();
  CkRegisterMigCtor(__idx, idx_WriteSession_CkMigrateMessage());

}
#endif /* CK_TEMPLATES_ONLY */

/* DEFS: array BufferChares: ArrayElement{
BufferChares(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers);
void sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
void sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
threaded void monitorRead();
void bufferReady();
void printTime(double time_taken);
BufferChares(CkMigrateMessage* impl_msg);
};
 */
#ifndef CK_TEMPLATES_ONLY
 int CkIndex_BufferChares::__idx=0;
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void CProxySection_BufferChares::contribute(CkSectionInfo &sid, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(sid, userData, fragSize);
}

void CProxySection_BufferChares::contribute(int dataSize,void *data,CkReduction::reducerType type, CkSectionInfo &sid, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(dataSize, data, type, sid, userData, fragSize);
}

template <typename T>
void CProxySection_BufferChares::contribute(std::vector<T> &data, CkReduction::reducerType type, CkSectionInfo &sid, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(data, type, sid, userData, fragSize);
}

void CProxySection_BufferChares::contribute(CkSectionInfo &sid, const CkCallback &cb, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(sid, cb, userData, fragSize);
}

void CProxySection_BufferChares::contribute(int dataSize,void *data,CkReduction::reducerType type, CkSectionInfo &sid, const CkCallback &cb, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(dataSize, data, type, sid, cb, userData, fragSize);
}

template <typename T>
void CProxySection_BufferChares::contribute(std::vector<T> &data, CkReduction::reducerType type, CkSectionInfo &sid, const CkCallback &cb, int userData, int fragSize)
{
   CkArray *ckarr = CProxy_CkArray(sid.get_aid()).ckLocalBranch();
   CkMulticastMgr *mCastGrp = CProxy_CkMulticastMgr(ckarr->getmCastMgr()).ckLocalBranch();
   mCastGrp->contribute(data, type, sid, cb, userData, fragSize);
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferChares(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers);
 */
void CProxyElement_BufferChares::insert(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers, int onPE, const CkEntryOptions *impl_e_opts)
{ 
   //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
  }
   UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
   ckInsert((CkArrayMessage *)impl_msg,CkIndex_BufferChares::idx_BufferChares_marshall1(),onPE);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
 */
void CProxyElement_BufferChares::sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
  }
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_sendData_marshall2(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
 */
void CProxyElement_BufferChares::sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
  }
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_sendDataHandler_marshall3(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: threaded void monitorRead();
 */
void CProxyElement_BufferChares::monitorRead(const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_monitorRead_void(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void bufferReady();
 */
void CProxyElement_BufferChares::bufferReady(const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_bufferReady_void(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void printTime(double time_taken);
 */
void CProxyElement_BufferChares::printTime(double time_taken, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: double time_taken
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|time_taken;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|time_taken;
  }
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_printTime_marshall6(),0);
}
void CkIndex_BufferChares::_call_redn_wrapper_printTime_marshall6(void* impl_msg, void* impl_obj_void)
{
  BufferChares* impl_obj = static_cast<BufferChares*> (impl_obj_void);
  char* impl_buf = (char*)((CkReductionMsg*)impl_msg)->getData();
  /*Unmarshall pup'd fields: double time_taken*/
  PUP::fromMem implP(impl_buf);
  /* non two-param case */
  PUP::detail::TemporaryObjectHolder<double> time_taken;
  implP|time_taken;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->printTime(std::move(time_taken.t));
  delete (CkReductionMsg*)impl_msg;
}

#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferChares(CkMigrateMessage* impl_msg);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferChares(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers);
 */
CkArrayID CProxy_BufferChares::ckNew(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers, const CkArrayOptions &opts, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
  }
  UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
  CkArrayID gId = ckCreateArray((CkArrayMessage *)impl_msg, CkIndex_BufferChares::idx_BufferChares_marshall1(), opts);
  return gId;
}
void CProxy_BufferChares::ckNew(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers, const CkArrayOptions &opts, CkCallback _ck_array_creation_cb, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
  }
  UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
  CkSendAsyncCreateArray(CkIndex_BufferChares::idx_BufferChares_marshall1(), _ck_array_creation_cb, opts, impl_msg);
}
CkArrayID CProxy_BufferChares::ckNew(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers, const int s1, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
  }
  CkArrayOptions opts(s1);
  UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
  CkArrayID gId = ckCreateArray((CkArrayMessage *)impl_msg, CkIndex_BufferChares::idx_BufferChares_marshall1(), opts);
  return gId;
}
void CProxy_BufferChares::ckNew(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers, const int s1, CkCallback _ck_array_creation_cb, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<FileToken>::type>::type &)file;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)num_readers;
  }
  CkArrayOptions opts(s1);
  UsrToEnv(impl_msg)->setMsgtype(ArrayEltInitMsg);
  CkSendAsyncCreateArray(CkIndex_BufferChares::idx_BufferChares_marshall1(), _ck_array_creation_cb, opts, impl_msg);
}

// Entry point registration function
int CkIndex_BufferChares::reg_BufferChares_marshall1() {
  int epidx = CkRegisterEp("BufferChares(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers)",
      reinterpret_cast<CkCallFnPtr>(_call_BufferChares_marshall1), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_BufferChares_marshall1);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_BufferChares_marshall1);

  return epidx;
}

void CkIndex_BufferChares::_call_BufferChares_marshall1(void* impl_msg, void* impl_obj_void)
{
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> num_readers;
  implP|num_readers;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  new (impl_obj_void) BufferChares(std::move(file.t), std::move(offset.t), std::move(bytes.t), std::move(num_readers.t));
}
int CkIndex_BufferChares::_callmarshall_BufferChares_marshall1(char* impl_buf, void* impl_obj_void) {
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> num_readers;
  implP|num_readers;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  new (impl_obj_void) BufferChares(std::move(file.t), std::move(offset.t), std::move(bytes.t), std::move(num_readers.t));
  return implP.size();
}
void CkIndex_BufferChares::_marshallmessagepup_BufferChares_marshall1(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<FileToken> file;
  implP|file;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<size_t> num_readers;
  implP|num_readers;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("file");
  implDestP|file;
  if (implDestP.hasComments()) implDestP.comment("offset");
  implDestP|offset;
  if (implDestP.hasComments()) implDestP.comment("bytes");
  implDestP|bytes;
  if (implDestP.hasComments()) implDestP.comment("num_readers");
  implDestP|num_readers;
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
 */
void CProxy_BufferChares::sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
  }
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckBroadcast(impl_amsg, CkIndex_BufferChares::idx_sendData_marshall2(),0);
}

// Entry point registration function
int CkIndex_BufferChares::reg_sendData_marshall2() {
  int epidx = CkRegisterEp("sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe)",
      reinterpret_cast<CkCallFnPtr>(_call_sendData_marshall2), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_sendData_marshall2);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_sendData_marshall2);

  return epidx;
}

void CkIndex_BufferChares::_call_sendData_marshall2(void* impl_msg, void* impl_obj_void)
{
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  PUP::fromMem implP(impl_buf);
  Closure_BufferChares::sendData_2_closure* genClosure = new Closure_BufferChares::sendData_2_closure();
  implP|genClosure->read_tag;
  implP|genClosure->buffer_tag;
  implP|genClosure->offset;
  implP|genClosure->bytes;
  implP|genClosure->ra;
  implP|genClosure->pe;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->sendData(genClosure);
  genClosure->deref();
}
int CkIndex_BufferChares::_callmarshall_sendData_marshall2(char* impl_buf, void* impl_obj_void) {
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  PUP::fromMem implP(impl_buf);
  Closure_BufferChares::sendData_2_closure* genClosure = new Closure_BufferChares::sendData_2_closure();
  implP|genClosure->read_tag;
  implP|genClosure->buffer_tag;
  implP|genClosure->offset;
  implP|genClosure->bytes;
  implP|genClosure->ra;
  implP|genClosure->pe;
  impl_buf+=CK_ALIGN(implP.size(),16);
  impl_obj->sendData(genClosure);
  genClosure->deref();
  return implP.size();
}
void CkIndex_BufferChares::_marshallmessagepup_sendData_marshall2(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<int> read_tag;
  implP|read_tag;
  PUP::detail::TemporaryObjectHolder<int> buffer_tag;
  implP|buffer_tag;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<CProxy_ReadAssembler> ra;
  implP|ra;
  PUP::detail::TemporaryObjectHolder<int> pe;
  implP|pe;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("read_tag");
  implDestP|read_tag;
  if (implDestP.hasComments()) implDestP.comment("buffer_tag");
  implDestP|buffer_tag;
  if (implDestP.hasComments()) implDestP.comment("offset");
  implDestP|offset;
  if (implDestP.hasComments()) implDestP.comment("bytes");
  implDestP|bytes;
  if (implDestP.hasComments()) implDestP.comment("ra");
  implDestP|ra;
  if (implDestP.hasComments()) implDestP.comment("pe");
  implDestP|pe;
}
PUPable_def(SINGLE_ARG(Closure_BufferChares::sendData_2_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
 */
void CProxy_BufferChares::sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
  }
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckBroadcast(impl_amsg, CkIndex_BufferChares::idx_sendDataHandler_marshall3(),0);
}

// Entry point registration function
int CkIndex_BufferChares::reg_sendDataHandler_marshall3() {
  int epidx = CkRegisterEp("sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe)",
      reinterpret_cast<CkCallFnPtr>(_call_sendDataHandler_marshall3), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_sendDataHandler_marshall3);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_sendDataHandler_marshall3);

  return epidx;
}

void CkIndex_BufferChares::_call_sendDataHandler_marshall3(void* impl_msg, void* impl_obj_void)
{
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<int> read_tag;
  implP|read_tag;
  PUP::detail::TemporaryObjectHolder<int> buffer_tag;
  implP|buffer_tag;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<CProxy_ReadAssembler> ra;
  implP|ra;
  PUP::detail::TemporaryObjectHolder<int> pe;
  implP|pe;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->sendDataHandler(std::move(read_tag.t), std::move(buffer_tag.t), std::move(offset.t), std::move(bytes.t), std::move(ra.t), std::move(pe.t));
}
int CkIndex_BufferChares::_callmarshall_sendDataHandler_marshall3(char* impl_buf, void* impl_obj_void) {
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<int> read_tag;
  implP|read_tag;
  PUP::detail::TemporaryObjectHolder<int> buffer_tag;
  implP|buffer_tag;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<CProxy_ReadAssembler> ra;
  implP|ra;
  PUP::detail::TemporaryObjectHolder<int> pe;
  implP|pe;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->sendDataHandler(std::move(read_tag.t), std::move(buffer_tag.t), std::move(offset.t), std::move(bytes.t), std::move(ra.t), std::move(pe.t));
  return implP.size();
}
void CkIndex_BufferChares::_marshallmessagepup_sendDataHandler_marshall3(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<int> read_tag;
  implP|read_tag;
  PUP::detail::TemporaryObjectHolder<int> buffer_tag;
  implP|buffer_tag;
  PUP::detail::TemporaryObjectHolder<size_t> offset;
  implP|offset;
  PUP::detail::TemporaryObjectHolder<size_t> bytes;
  implP|bytes;
  PUP::detail::TemporaryObjectHolder<CProxy_ReadAssembler> ra;
  implP|ra;
  PUP::detail::TemporaryObjectHolder<int> pe;
  implP|pe;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("read_tag");
  implDestP|read_tag;
  if (implDestP.hasComments()) implDestP.comment("buffer_tag");
  implDestP|buffer_tag;
  if (implDestP.hasComments()) implDestP.comment("offset");
  implDestP|offset;
  if (implDestP.hasComments()) implDestP.comment("bytes");
  implDestP|bytes;
  if (implDestP.hasComments()) implDestP.comment("ra");
  implDestP|ra;
  if (implDestP.hasComments()) implDestP.comment("pe");
  implDestP|pe;
}
PUPable_def(SINGLE_ARG(Closure_BufferChares::sendDataHandler_3_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: threaded void monitorRead();
 */
void CProxy_BufferChares::monitorRead(const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckBroadcast(impl_amsg, CkIndex_BufferChares::idx_monitorRead_void(),0);
}

// Entry point registration function
int CkIndex_BufferChares::reg_monitorRead_void() {
  int epidx = CkRegisterEp("monitorRead()",
      reinterpret_cast<CkCallFnPtr>(_call_monitorRead_void), 0, __idx, 0);
  return epidx;
}

void CkIndex_BufferChares::_call_monitorRead_void(void* impl_msg, void* impl_obj_void)
{
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  CthThread tid = CthCreate((CthVoidFn)_callthr_monitorRead_void, new CkThrCallArg(impl_msg,impl_obj), 0);
  ((Chare *)impl_obj)->CkAddThreadListeners(tid,impl_msg);
  CthTraceResume(tid);
  CthResume(tid);
}
void CkIndex_BufferChares::_callthr_monitorRead_void(CkThrCallArg *impl_arg)
{
  void *impl_msg = impl_arg->msg;
  void *impl_obj_void = impl_arg->obj;
  BufferChares *impl_obj = static_cast<BufferChares *>(impl_obj_void);
  delete impl_arg;
  impl_obj->monitorRead();
  if(UsrToEnv(impl_msg)->isVarSysMsg() == 0)
    CkFreeSysMsg(impl_msg);
}
PUPable_def(SINGLE_ARG(Closure_BufferChares::monitorRead_4_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void bufferReady();
 */
void CProxy_BufferChares::bufferReady(const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckBroadcast(impl_amsg, CkIndex_BufferChares::idx_bufferReady_void(),0);
}

// Entry point registration function
int CkIndex_BufferChares::reg_bufferReady_void() {
  int epidx = CkRegisterEp("bufferReady()",
      reinterpret_cast<CkCallFnPtr>(_call_bufferReady_void), 0, __idx, 0);
  return epidx;
}

void CkIndex_BufferChares::_call_bufferReady_void(void* impl_msg, void* impl_obj_void)
{
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  impl_obj->_sdag_fnc_bufferReady();
  if(UsrToEnv(impl_msg)->isVarSysMsg() == 0)
    CkFreeSysMsg(impl_msg);
}
PUPable_def(SINGLE_ARG(Closure_BufferChares::bufferReady_5_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void printTime(double time_taken);
 */
void CProxy_BufferChares::printTime(double time_taken, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: double time_taken
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|time_taken;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|time_taken;
  }
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckBroadcast(impl_amsg, CkIndex_BufferChares::idx_printTime_marshall6(),0);
}

// Entry point registration function
int CkIndex_BufferChares::reg_printTime_marshall6() {
  int epidx = CkRegisterEp("printTime(double time_taken)",
      reinterpret_cast<CkCallFnPtr>(_call_printTime_marshall6), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_printTime_marshall6);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_printTime_marshall6);

  return epidx;
}


// Redn wrapper registration function
int CkIndex_BufferChares::reg_redn_wrapper_printTime_marshall6() {
  return CkRegisterEp("redn_wrapper_printTime(CkReductionMsg *impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_redn_wrapper_printTime_marshall6), CkMarshallMsg::__idx, __idx, 0);
}

void CkIndex_BufferChares::_call_printTime_marshall6(void* impl_msg, void* impl_obj_void)
{
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: double time_taken*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<double> time_taken;
  implP|time_taken;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->printTime(std::move(time_taken.t));
}
int CkIndex_BufferChares::_callmarshall_printTime_marshall6(char* impl_buf, void* impl_obj_void) {
  BufferChares* impl_obj = static_cast<BufferChares*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: double time_taken*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<double> time_taken;
  implP|time_taken;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  impl_obj->printTime(std::move(time_taken.t));
  return implP.size();
}
void CkIndex_BufferChares::_marshallmessagepup_printTime_marshall6(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: double time_taken*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<double> time_taken;
  implP|time_taken;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("time_taken");
  implDestP|time_taken;
}
PUPable_def(SINGLE_ARG(Closure_BufferChares::printTime_6_closure))
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferChares(CkMigrateMessage* impl_msg);
 */

// Entry point registration function
int CkIndex_BufferChares::reg_BufferChares_CkMigrateMessage() {
  int epidx = CkRegisterEp("BufferChares(CkMigrateMessage* impl_msg)",
      reinterpret_cast<CkCallFnPtr>(_call_BufferChares_CkMigrateMessage), 0, __idx, 0);
  return epidx;
}

void CkIndex_BufferChares::_call_BufferChares_CkMigrateMessage(void* impl_msg, void* impl_obj_void)
{
  call_migration_constructor<BufferChares> c = impl_obj_void;
  c((CkMigrateMessage*)impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferChares(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
 */
void CProxySection_BufferChares::sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
  }
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_sendData_marshall2(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
 */
void CProxySection_BufferChares::sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|read_tag;
    implP|buffer_tag;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)offset;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<size_t>::type>::type &)bytes;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<CProxy_ReadAssembler>::type>::type &)ra;
    implP|pe;
  }
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_sendDataHandler_marshall3(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: threaded void monitorRead();
 */
void CProxySection_BufferChares::monitorRead(const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_monitorRead_void(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void bufferReady();
 */
void CProxySection_BufferChares::bufferReady(const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_bufferReady_void(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: void printTime(double time_taken);
 */
void CProxySection_BufferChares::printTime(double time_taken, const CkEntryOptions *impl_e_opts) 
{
  ckCheck();
  //Marshall: double time_taken
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    implP|time_taken;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    implP|time_taken;
  }
  UsrToEnv(impl_msg)->setMsgtype(ForArrayEltMsg);
  CkArrayMessage *impl_amsg=(CkArrayMessage *)impl_msg;
  impl_amsg->array_setIfNotThere(CkArray_IfNotThere_buffer);
  ckSend(impl_amsg, CkIndex_BufferChares::idx_printTime_marshall6(),0);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferChares(CkMigrateMessage* impl_msg);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void CkIndex_BufferChares::__register(const char *s, size_t size) {
  __idx = CkRegisterChare(s, size, TypeArray);
  CkRegisterArrayDimensions(__idx, 1);
  CkRegisterBase(__idx, CkIndex_ArrayElement::__idx);
  // REG: BufferChares(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers);
  idx_BufferChares_marshall1();

  // REG: void sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
  idx_sendData_marshall2();

  // REG: void sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
  idx_sendDataHandler_marshall3();

  // REG: threaded void monitorRead();
  idx_monitorRead_void();

  // REG: void bufferReady();
  idx_bufferReady_void();

  // REG: void printTime(double time_taken);
  idx_printTime_marshall6();
  idx_redn_wrapper_printTime_marshall6();

  // REG: BufferChares(CkMigrateMessage* impl_msg);
  idx_BufferChares_CkMigrateMessage();
  CkRegisterMigCtor(__idx, idx_BufferChares_CkMigrateMessage());

  BufferChares::__sdag_register(); // Potentially missing BufferChares_SDAG_CODE in your class definition?
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
void BufferChares::bufferReady(){
  CkPrintf("Error> Direct call to SDAG entry method \'%s::%s\'!\n", "BufferChares", "bufferReady()"); 
  CkAbort("Direct SDAG call is not allowed for SDAG entry methods having when constructs. Call such SDAG methods using a proxy"); 
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void BufferChares::_sdag_fnc_bufferReady() {
  _TRACE_END_EXECUTE(); 
  if (!__dep.get()) _sdag_init();
  _slist_0();
  CmiObjId projID = this->ckGetArrayIndex().getProjectionID();
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, &projID, this); 
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::bufferReady_end() {
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_slist_0() {
  _while_0();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_slist_0_end() {
  bufferReady_end();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_while_0() {
  if (true) {
    _slist_1();
  } else {
    _slist_0_end();
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_while_0_end() {
  if (true) {
    _slist_1();
  } else {
    _slist_0_end();
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_slist_1() {
  _when_0();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_slist_1_end() {
  _while_0_end();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
SDAG::Continuation* BufferChares::_when_0() {
  SDAG::Buffer* buf0 = __dep->tryFindMessage(0, false, 0, 0);
  if (buf0) {
    __dep->removeMessage(buf0);
    _slist_2(static_cast<Closure_BufferChares::sendData_2_closure*>(buf0->cl));
    delete buf0;
    return 0;
  } else {
    SDAG::Continuation* c = new SDAG::Continuation(0);
    c->anyEntries.push_back(0);
    __dep->reg(c);
    return c;
  }
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_when_0_end(Closure_BufferChares::sendData_2_closure* gen0) {
  _slist_1_end();
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_slist_2(Closure_BufferChares::sendData_2_closure* gen0) {
  _serial_0(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_slist_2_end(Closure_BufferChares::sendData_2_closure* gen0) {
  _when_0_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_serial_0(Closure_BufferChares::sendData_2_closure* gen0) {
  CmiObjId projID = this->ckGetArrayIndex().getProjectionID();
  _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, (_sdag_idx_BufferChares_serial_0()), CkMyPe(), 0, &projID, this); 
  {
    int& read_tag = gen0->getP0();
    int& buffer_tag = gen0->getP1();
    size_t& offset = gen0->getP2();
    size_t& bytes = gen0->getP3();
    CProxy_ReadAssembler& ra = gen0->getP4();
    int& pe = gen0->getP5();
    { // begin serial block
#line 150 "ckio.ci"
thisProxy[thisIndex].sendDataHandler(read_tag, buffer_tag, offset, bytes, ra, pe);
#line 6759 "CkIO_impl.def.h"
    } // end serial block
  }
  _TRACE_END_EXECUTE(); 
  _slist_2_end(gen0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::sendData(int read_tag, int buffer_tag, size_t offset, size_t bytes, CProxy_ReadAssembler ra, int pe){
  Closure_BufferChares::sendData_2_closure* genClosure = new Closure_BufferChares::sendData_2_closure();
  genClosure->getP0() = read_tag;
  genClosure->getP1() = buffer_tag;
  genClosure->getP2() = offset;
  genClosure->getP3() = bytes;
  genClosure->getP4() = ra;
  genClosure->getP5() = pe;
  sendData(genClosure);
  genClosure->deref();
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void BufferChares::sendData(Closure_BufferChares::sendData_2_closure* genClosure){
  if (!__dep.get()) _sdag_init();
  __dep->pushBuffer(0, genClosure);
  SDAG::Continuation* c = __dep->tryFindContinuation(0);
  if (c) {
    _TRACE_END_EXECUTE(); 
    _when_0(
    );
    CmiObjId projID = this->ckGetArrayIndex().getProjectionID();
    _TRACE_BEGIN_EXECUTE_DETAILED(-1, -1, _sdagEP, CkMyPe(), 0, &projID, this); 
    delete c;
  }
}

#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void BufferChares::_sdag_init() { // Potentially missing BufferChares_SDAG_CODE in your class definition?
  __dep.reset(new SDAG::Dependency(1,1));
  __dep->addDepends(0,0);
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::__sdag_init() { // Potentially missing BufferChares_SDAG_CODE in your class definition?
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
void BufferChares::_sdag_pup(PUP::er &p) {  // Potentially missing BufferChares_SDAG_CODE in your class definition?
  p|__dep;
}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void BufferChares::__sdag_register() { // Potentially missing BufferChares_SDAG_CODE in your class definition?
  (void)_sdag_idx_BufferChares_serial_0();
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::sendData_2_closure));
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::sendDataHandler_3_closure));
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::monitorRead_4_closure));
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::bufferReady_5_closure));
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::printTime_6_closure));
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::sendData_2_closure));
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::sendDataHandler_3_closure));
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::monitorRead_4_closure));
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::bufferReady_5_closure));
  PUPable_reg(SINGLE_ARG(Closure_BufferChares::printTime_6_closure));
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int BufferChares::_sdag_idx_BufferChares_serial_0() { // Potentially missing BufferChares_SDAG_CODE in your class definition?
  static int epidx = _sdag_reg_BufferChares_serial_0();
  return epidx;
}
#endif /* CK_TEMPLATES_ONLY */


#ifndef CK_TEMPLATES_ONLY
int BufferChares::_sdag_reg_BufferChares_serial_0() { // Potentially missing BufferChares_SDAG_CODE in your class definition?
  return CkRegisterEp("BufferChares_serial_0", NULL, 0, CkIndex_BufferChares::__idx, 0);
}
#endif /* CK_TEMPLATES_ONLY */



/* DEFS: group Map: CkArrayMap{
Map();
};
 */
#ifndef CK_TEMPLATES_ONLY
 int CkIndex_Map::__idx=0;
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
/* DEFS: Map();
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: Map();
 */
CkGroupID CProxy_Map::ckNew(const CkEntryOptions *impl_e_opts)
{
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(BocInitMsg);
  CkGroupID gId = CkCreateGroup(CkIndex_Map::__idx, CkIndex_Map::idx_Map_void(), impl_msg);
  return gId;
}

// Entry point registration function
int CkIndex_Map::reg_Map_void() {
  int epidx = CkRegisterEp("Map()",
      reinterpret_cast<CkCallFnPtr>(_call_Map_void), 0, __idx, 0);
  return epidx;
}

void CkIndex_Map::_call_Map_void(void* impl_msg, void* impl_obj_void)
{
  Map* impl_obj = static_cast<Map*>(impl_obj_void);
  new (impl_obj_void) Map();
  if(UsrToEnv(impl_msg)->isVarSysMsg() == 0)
    CkFreeSysMsg(impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: Map();
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void CkIndex_Map::__register(const char *s, size_t size) {
  __idx = CkRegisterChare(s, size, TypeGroup);
  CkRegisterBase(__idx, CkIndex_CkArrayMap::__idx);
   CkRegisterGroupIrr(__idx,Map::isIrreducible());
  // REG: Map();
  idx_Map_void();
  CkRegisterDefaultCtor(__idx, idx_Map_void());

}
#endif /* CK_TEMPLATES_ONLY */

} // namespace impl

/* DEFS: group BufferNodeMap: CkArrayMap{
BufferNodeMap();
BufferNodeMap(const std::vector<int> &processors);
};
 */
#ifndef CK_TEMPLATES_ONLY
 int CkIndex_BufferNodeMap::__idx=0;
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferNodeMap();
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferNodeMap(const std::vector<int> &processors);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferNodeMap();
 */
CkGroupID CProxy_BufferNodeMap::ckNew(const CkEntryOptions *impl_e_opts)
{
  void *impl_msg = CkAllocSysMsg(impl_e_opts);
  UsrToEnv(impl_msg)->setMsgtype(BocInitMsg);
  CkGroupID gId = CkCreateGroup(CkIndex_BufferNodeMap::__idx, CkIndex_BufferNodeMap::idx_BufferNodeMap_void(), impl_msg);
  return gId;
}

// Entry point registration function
int CkIndex_BufferNodeMap::reg_BufferNodeMap_void() {
  int epidx = CkRegisterEp("BufferNodeMap()",
      reinterpret_cast<CkCallFnPtr>(_call_BufferNodeMap_void), 0, __idx, 0);
  return epidx;
}

void CkIndex_BufferNodeMap::_call_BufferNodeMap_void(void* impl_msg, void* impl_obj_void)
{
  BufferNodeMap* impl_obj = static_cast<BufferNodeMap*>(impl_obj_void);
  new (impl_obj_void) BufferNodeMap();
  if(UsrToEnv(impl_msg)->isVarSysMsg() == 0)
    CkFreeSysMsg(impl_msg);
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferNodeMap(const std::vector<int> &processors);
 */
CkGroupID CProxy_BufferNodeMap::ckNew(const std::vector<int> &processors, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const std::vector<int> &processors
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::vector<int>>::type>::type &)processors;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::vector<int>>::type>::type &)processors;
  }
  UsrToEnv(impl_msg)->setMsgtype(BocInitMsg);
  CkGroupID gId = CkCreateGroup(CkIndex_BufferNodeMap::__idx, CkIndex_BufferNodeMap::idx_BufferNodeMap_marshall2(), impl_msg);
  return gId;
}
  CProxy_BufferNodeMap::CProxy_BufferNodeMap(const std::vector<int> &processors, const CkEntryOptions *impl_e_opts)
{
  //Marshall: const std::vector<int> &processors
  int impl_off=0;
  { //Find the size of the PUP'd data
    PUP::sizer implP;
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::vector<int>>::type>::type &)processors;
    impl_off+=implP.size();
  }
  CkMarshallMsg *impl_msg=CkAllocateMarshallMsg(impl_off,impl_e_opts);
  { //Copy over the PUP'd data
    PUP::toMem implP((void *)impl_msg->msgBuf);
    //Have to cast away const-ness to get pup routine
    implP|(typename std::remove_cv<typename std::remove_reference<std::vector<int>>::type>::type &)processors;
  }
  UsrToEnv(impl_msg)->setMsgtype(BocInitMsg);
  ckSetGroupID(CkCreateGroup(CkIndex_BufferNodeMap::__idx, CkIndex_BufferNodeMap::idx_BufferNodeMap_marshall2(), impl_msg));
}

// Entry point registration function
int CkIndex_BufferNodeMap::reg_BufferNodeMap_marshall2() {
  int epidx = CkRegisterEp("BufferNodeMap(const std::vector<int> &processors)",
      reinterpret_cast<CkCallFnPtr>(_call_BufferNodeMap_marshall2), CkMarshallMsg::__idx, __idx, 0+CK_EP_NOKEEP);
  CkRegisterMarshallUnpackFn(epidx, _callmarshall_BufferNodeMap_marshall2);
  CkRegisterMessagePupFn(epidx, _marshallmessagepup_BufferNodeMap_marshall2);

  return epidx;
}

void CkIndex_BufferNodeMap::_call_BufferNodeMap_marshall2(void* impl_msg, void* impl_obj_void)
{
  BufferNodeMap* impl_obj = static_cast<BufferNodeMap*>(impl_obj_void);
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const std::vector<int> &processors*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<std::vector<int>> processors;
  implP|processors;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  new (impl_obj_void) BufferNodeMap(std::move(processors.t));
}
int CkIndex_BufferNodeMap::_callmarshall_BufferNodeMap_marshall2(char* impl_buf, void* impl_obj_void) {
  BufferNodeMap* impl_obj = static_cast<BufferNodeMap*>(impl_obj_void);
  envelope *env = UsrToEnv(impl_buf);
  /*Unmarshall pup'd fields: const std::vector<int> &processors*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<std::vector<int>> processors;
  implP|processors;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  new (impl_obj_void) BufferNodeMap(std::move(processors.t));
  return implP.size();
}
void CkIndex_BufferNodeMap::_marshallmessagepup_BufferNodeMap_marshall2(PUP::er &implDestP,void *impl_msg) {
  CkMarshallMsg *impl_msg_typed=(CkMarshallMsg *)impl_msg;
  char *impl_buf=impl_msg_typed->msgBuf;
  envelope *env = UsrToEnv(impl_msg_typed);
  /*Unmarshall pup'd fields: const std::vector<int> &processors*/
  PUP::fromMem implP(impl_buf);
  PUP::detail::TemporaryObjectHolder<std::vector<int>> processors;
  implP|processors;
  impl_buf+=CK_ALIGN(implP.size(),16);
  /*Unmarshall arrays:*/
  if (implDestP.hasComments()) implDestP.comment("processors");
  implDestP|processors;
}
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferNodeMap();
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
/* DEFS: BufferNodeMap(const std::vector<int> &processors);
 */
#endif /* CK_TEMPLATES_ONLY */

#ifndef CK_TEMPLATES_ONLY
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
void CkIndex_BufferNodeMap::__register(const char *s, size_t size) {
  __idx = CkRegisterChare(s, size, TypeGroup);
  CkRegisterBase(__idx, CkIndex_CkArrayMap::__idx);
   CkRegisterGroupIrr(__idx,BufferNodeMap::isIrreducible());
  // REG: BufferNodeMap();
  idx_BufferNodeMap_void();
  CkRegisterDefaultCtor(__idx, idx_BufferNodeMap_void());

  // REG: BufferNodeMap(const std::vector<int> &processors);
  idx_BufferNodeMap_marshall2();

}
#endif /* CK_TEMPLATES_ONLY */

} // namespace IO

} // namespace Ck

#ifndef CK_TEMPLATES_ONLY
void _registerCkIO_impl(void)
{
  static int _done = 0; if(_done) return; _done = 1;

using namespace Ck;
using namespace IO;
using namespace impl;
  CkRegisterReadonly("director","CProxy_Director",sizeof(director),(void *) &director,__xlater_roPup_director);

/* REG: mainchare Director: Chare{
Director(CkArgMsg* impl_msg);
void openFile(const std::string &name, const CkCallback &opened, const Options &opts);
void fileOpened(const FileToken &file);
void sessionComplete(const FileToken &file);
void closeReadSession(const Session &impl_noname_0, const CkCallback &impl_noname_1);
void prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready);
void prepareReadSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const std::vector<int> &pes_to_map);
void prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const CkCallback &complete);
void prepareWriteSession(const FileToken &file, const size_t &bytes, const size_t &offset, const CkCallback &ready, const char *commitData, const size_t &commitBytes, const size_t &commitOffset, const CkCallback &complete);
void sessionReady(CkReductionMsg* impl_msg);
void sessionDone(CkReductionMsg* impl_msg);
void close(const FileToken &token, const CkCallback &closed);
void addSessionReadAssemblerFinished(CkReductionMsg* impl_msg);
Director(CkMigrateMessage* impl_msg);
};
*/
  CkIndex_Director::__register("Director", sizeof(Director));

/* REG: group ReadAssembler: IrrGroup{
ReadAssembler(const Session &session);
void shareData(int read_tag, int buffer_tag, const size_t &read_chare_offset, const size_t &num_bytes, CkNcpyBuffer ncpyBuffer_data);
};
*/
  CkIndex_ReadAssembler::__register("ReadAssembler", sizeof(ReadAssembler));

/* REG: group Manager: IrrGroup{
Manager();
void run();
void openFile(unsigned int opnum, const FileToken &token, const std::string &name, const Options &opts);
void close(unsigned int opnum, const FileToken &token, const CkCallback &closed);
void addSessionReadAssemblerMapping(const Session &session, const CProxy_ReadAssembler &ra, const CkCallback &ready);
Manager(CkMigrateMessage* impl_msg);
};
*/
  CkIndex_Manager::__register("Manager", sizeof(Manager));

/* REG: array WriteSession: ArrayElement{
WriteSession(const FileToken &file, const size_t &offset, const size_t &bytes);
void forwardData(const char *data, const size_t &bytes, const size_t &offset);
void syncData();
WriteSession(CkMigrateMessage* impl_msg);
};
*/
  CkIndex_WriteSession::__register("WriteSession", sizeof(WriteSession));

/* REG: array BufferChares: ArrayElement{
BufferChares(const FileToken &file, const size_t &offset, const size_t &bytes, const size_t &num_readers);
void sendData(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
void sendDataHandler(int read_tag, int buffer_tag, const size_t &offset, const size_t &bytes, const CProxy_ReadAssembler &ra, int pe);
threaded void monitorRead();
void bufferReady();
void printTime(double time_taken);
BufferChares(CkMigrateMessage* impl_msg);
};
*/
  CkIndex_BufferChares::__register("BufferChares", sizeof(BufferChares));

/* REG: group Map: CkArrayMap{
Map();
};
*/
  CkIndex_Map::__register("Map", sizeof(Map));


/* REG: group BufferNodeMap: CkArrayMap{
BufferNodeMap();
BufferNodeMap(const std::vector<int> &processors);
};
*/
  CkIndex_BufferNodeMap::__register("BufferNodeMap", sizeof(BufferNodeMap));



}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
template <>
void Ck::IO::impl::CBase_Director::virtual_pup(PUP::er &p) {
    recursive_pup<Ck::IO::impl::Director>(dynamic_cast<Ck::IO::impl::Director*>(this), p);
}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
template <>
void Ck::IO::impl::CBase_ReadAssembler::virtual_pup(PUP::er &p) {
    recursive_pup<Ck::IO::impl::ReadAssembler>(dynamic_cast<Ck::IO::impl::ReadAssembler*>(this), p);
}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
template <>
void Ck::IO::impl::CBase_Manager::virtual_pup(PUP::er &p) {
    recursive_pup<Ck::IO::impl::Manager>(dynamic_cast<Ck::IO::impl::Manager*>(this), p);
}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
template <>
void Ck::IO::impl::CBase_WriteSession::virtual_pup(PUP::er &p) {
    recursive_pup<Ck::IO::impl::WriteSession>(dynamic_cast<Ck::IO::impl::WriteSession*>(this), p);
}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
template <>
void Ck::IO::impl::CBase_BufferChares::virtual_pup(PUP::er &p) {
    recursive_pup<Ck::IO::impl::BufferChares>(dynamic_cast<Ck::IO::impl::BufferChares*>(this), p);
}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
template <>
void Ck::IO::impl::CBase_Map::virtual_pup(PUP::er &p) {
    recursive_pup<Ck::IO::impl::Map>(dynamic_cast<Ck::IO::impl::Map*>(this), p);
}
#endif /* CK_TEMPLATES_ONLY */
#ifndef CK_TEMPLATES_ONLY
template <>
void Ck::IO::CBase_BufferNodeMap::virtual_pup(PUP::er &p) {
    recursive_pup<Ck::IO::BufferNodeMap>(dynamic_cast<Ck::IO::BufferNodeMap*>(this), p);
}
#endif /* CK_TEMPLATES_ONLY */
