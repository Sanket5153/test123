#ifndef _DECL_CkDummy_H_
#define _DECL_CkDummy_H_
#include "charm++.h"
#include "envelope.h"
#include <memory>
#include "sdag.h"


extern void _registerCkDummy(void);
#endif
